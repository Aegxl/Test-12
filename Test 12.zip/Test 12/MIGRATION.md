# Migration Guide

This guide explains how to migrate from the original single-file `app.py` to the new structured version.

## What Changed

### File Structure
The original single `app.py` file (2000+ lines) has been split into multiple organized modules:

- **Models** are now in separate files under `app/models/`
- **Templates** are organized by feature in `app/templates/`
- **Routes** are separated by functionality in `app/routes/`
- **Utilities** are in `app/utils/`
- **Configuration** is centralized in `app/config.py`

### No Breaking Changes
⚠️ **Important**: The functionality remains exactly the same. No API endpoints, database schema, or user-facing features have been changed.

## Migration Steps

### 1. Backup Your Data
```bash
# If using SQLite (default)
cp market.db market.db.backup

# If using PostgreSQL/MySQL, create a database dump
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Environment Variables
Create a `.env` file based on `.env.example`:
```bash
cp .env.example .env
# Edit .env with your settings
```

### 4. Run the New Version
```bash
# Development
python main.py

# Or with uvicorn directly
uvicorn app.main:app --reload --port 8000
```

### 5. Verify Everything Works
- Test login with existing accounts
- Check that existing jobs are visible
- Verify chat history is preserved
- Test all admin functions

## Database Compatibility

The new version uses the **exact same database schema**. Your existing SQLite file (`market.db`) will work without any changes.

## Configuration Changes

Environment variables remain the same:
- `SECRET_KEY`
- `DB_URL` 
- `UPLOAD_DIR`
- `SMTP_*` settings
- `TELEGRAM_*` settings
- `MAX_RECRUITERS_PER_JOB`

## Key Benefits of New Structure

### 1. **Maintainability**
- Each file has a single responsibility
- Easy to find and modify specific features
- Better code organization

### 2. **Scalability**
- Easy to add new features
- Clear separation of concerns
- Modular architecture

### 3. **Team Development**
- Multiple developers can work on different parts
- Reduced merge conflicts
- Better code review process

### 4. **Testing**
- Individual components can be tested separately
- Better test organization
- Easier to mock dependencies

## File Mapping

Here's where the original code sections moved:

| Original Section | New Location |
|------------------|--------------|
| Database models | `app/models/*.py` |
| Templates | `app/templates/*.py` |
| Auth routes | `app/routes/auth.py` |
| Job management | `app/routes/jobs.py` |
| Chat/WebSocket | `app/routes/chat.py` |
| Admin panel | `app/routes/admin.py` |
| CMS/Pages | `app/routes/cms.py` |
| Utilities | `app/utils/*.py` |
| Configuration | `app/config.py` |

## Troubleshooting

### Import Errors
If you get import errors, ensure you're running from the project root and `PYTHONPATH` is set correctly:
```bash
export PYTHONPATH=/path/to/project
python main.py
```

### Database Issues
If you get database errors:
1. Check `DB_URL` is correct
2. Ensure database file permissions are correct
3. Verify all models are imported in `app/models/__init__.py`

### Template Errors
If templates don't render:
1. Check all templates are included in their respective files
2. Verify template names match route references
3. Ensure Jinja2 environment is properly configured

## Rollback Plan

If you need to rollback to the original single file:
1. Stop the new version
2. Restore your backup of the original `app.py`
3. Restore database backup if needed
4. Run the original version

## Need Help?

If you encounter issues during migration:
1. Check the logs for specific error messages
2. Verify your environment variables
3. Test with a fresh database to isolate issues
4. Compare your configuration with `.env.example`

The structured version maintains 100% compatibility with the original, so migration should be seamless.