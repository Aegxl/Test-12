from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean
from sqlalchemy.orm import relationship
from passlib.hash import pbkdf2_sha256 as hasher

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(200), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False)  # employer|recruiter|admin
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    accepted_terms_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    jobs = relationship("Job", back_populates="employer", cascade="all, delete")

    def verify_password(self, password: str) -> bool:
        """Verify password against hash"""
        try:
            return hasher.verify(password, self.password_hash)
        except Exception:
            return False