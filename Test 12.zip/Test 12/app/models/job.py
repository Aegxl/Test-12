from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey, Float, Boolean, UniqueConstraint
from sqlalchemy.orm import relationship

from app.database import Base


class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    reward = Column(Float, nullable=False)
    status = Column(String(20), default="pending")  # pending -> open -> closed
    city = Column(String(120), default="")
    is_remote = Column(Boolean, default=False)
    level = Column(String(20), default="")  # junior|middle|senior
    tags = Column(String(300), default="")  # comma-separated
    created_at = Column(DateTime, default=datetime.utcnow)

    # Foreign keys
    employer_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    # Relationships
    employer = relationship("User", back_populates="jobs")
    assignments = relationship("JobRecruiter", back_populates="job", cascade="all, delete")


class JobRecruiter(Base):
    __tablename__ = "job_recruiters"

    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    recruiter_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    status = Column(String(20), default="active")  # active, dropped
    pipeline_status = Column(String(20), default="приглашён")  # приглашён, интервью, оффер, закрыто
    assigned_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    job = relationship("Job", back_populates="assignments")
    recruiter = relationship("User")

    __table_args__ = (UniqueConstraint("job_id", "recruiter_id", name="uq_job_recruiter"),)