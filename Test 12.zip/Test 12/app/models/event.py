from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey

from app.database import Base


class Event(Base):
    __tablename__ = "events"

    id = Column(Integer, primary_key=True)
    type = Column(String(50),
                  nullable=False)  # job_created, job_opened, job_closed, assignment_taken, message, invoice_sent, invoice_paid, user_blocked, user_unblocked, recruiter_dropped
    actor_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=True)
    recruiter_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    invoice_id = Column(Integer, ForeignKey("invoices.id"), nullable=True)
    meta = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)