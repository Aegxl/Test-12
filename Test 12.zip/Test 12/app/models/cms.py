from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean

from app.database import Base


class Page(Base):
    __tablename__ = "pages"

    id = Column(Integer, primary_key=True)
    slug = Column(String(64), unique=True, nullable=False)  # "rules", "terms", "privacy", "about"
    title = Column(String(200), nullable=False)
    content = Column(Text, default="")
    is_public = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class FaqItem(Base):
    __tablename__ = "faq_items"

    id = Column(Integer, primary_key=True)
    question = Column(String(300), nullable=False)
    answer = Column(Text, nullable=False)
    rank = Column(Integer, default=0)
    is_public = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)