"""
Main FastAPI application
"""
from datetime import datetime
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from passlib.hash import pbkdf2_sha256 as hasher

from app.config import SECRET_KEY, UPLOAD_DIR, MAX_RECRUITERS_PER_JOB
from app.database import engine, SessionLocal, get_db, Base
from app.templates import get_jinja_env
from app.dependencies import current_user
from app.routes import include_routers

# Import all models to ensure they're registered with Base
from app.models import User, Job, JobRecruiter, Message, Attachment, Invoice, Event, Page, FaqItem

# Create tables
Base.metadata.create_all(bind=engine)

# Initialize FastAPI app
app = FastAPI(title="HR Team")

# Add middleware
app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    session_cookie="hrteam_session",
    same_site="lax"
)

# Mount static files
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# Get template environment
env = get_jinja_env()


def render(name: str, request: Request, **context) -> HTMLResponse:
    """Helper: render template with common context"""
    with SessionLocal() as db:
        user = current_user(request, db)
    now = datetime.utcnow()
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": now,
        "max_recr": MAX_RECRUITERS_PER_JOB,
        **context
    })
    return HTMLResponse(html)


# Landing page
@app.get("/", response_class=HTMLResponse)
async def landing(request: Request):
    return render("landing.html", request, title="HR Team")


# Health check
@app.get("/healthz")
async def healthz():
    return {"ok": True, "time": datetime.utcnow().isoformat() + "Z"}


# Include all route modules


from starlette.middleware.base import BaseHTTPMiddleware
import time
from collections import defaultdict, deque

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, max_per_minute=240, burst=120):
        super().__init__(app)
        self.max_per_minute = max_per_minute
        self.burst = burst
        self.buckets = defaultdict(lambda: deque())

    async def dispatch(self, request, call_next):
        ip = getattr(getattr(request, "client", None), "host", "0.0.0.0")
        now = time.time()
        dq = self.buckets[ip]
        while dq and now - dq[0] > 60:
            dq.popleft()
        if len(dq) >= self.max_per_minute + self.burst:
            from starlette.responses import PlainTextResponse
            return PlainTextResponse("Too Many Requests", status_code=429)
        dq.append(now)
        return await call_next(request)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://unpkg.com; "
            "style-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com; "
            "img-src 'self' data: blob:; "
            "font-src 'self' data:; "
            "connect-src 'self' wss:; "
            "frame-ancestors 'none'"
        )
        resp.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
        return resp

include_routers(app)

app.add_middleware(RateLimitMiddleware)
app.add_middleware(SecurityHeadersMiddleware)


# Bootstrap data on startup
@app.on_event("startup")
def bootstrap():
    """Bootstrap admin user and default data"""
    from app.models import User, Page, FaqItem

    with SessionLocal() as db:
        # Create admin user if none exists
        has_admin = db.query(User).filter(User.role == "admin").first()
        if not has_admin:
            admin = User(
                name="Admin",
                email="admin@otvet.kz",
                password_hash=hasher.hash("admin"),
                role="admin",
                is_active=True,
                is_verified=True,
                accepted_terms_at=datetime.utcnow()
            )
            db.add(admin)
            db.commit()

        # Create default pages
        ensure_default_pages(db)
        ensure_default_faq(db)


def ensure_default_pages(db):
    """Create default CMS pages"""
    defaults = [
        ("rules", "Правила сайта", "Здесь будут ваши правила сайта. Замените этот текст в админке → Страницы."),
        ("terms", "Условия пользования", "Здесь разместите условия пользования сервисом."),
        ("privacy", "Политика конфиденциальности", "Опишите политику обработки персональных данных."),
        ("about", "О сервисе", "Коротко расскажите о площадке и принципах работы."),
    ]
    for slug, title, content in defaults:
        if not db.query(Page).filter_by(slug=slug).first():
            db.add(Page(slug=slug, title=title, content=content, is_public=True))
    db.commit()


def ensure_default_faq(db):
    """Create default FAQ items"""
    if db.query(FaqItem).count() == 0:
        samples = [
            ("Как рекрутер берёт в работу заявку?", "Зайдите в Панель → \"Доступные заявки\" и нажмите «Взяться». На одну заявку допускается до %d рекрутеров." % MAX_RECRUITERS_PER_JOB),
            ("Как отправить резюме/файл?", "Откройте чат по заявке и прикрепите файл через иконку 📎."),
            ("Можно ли заблокировать пользователя-нарушителя?", "Да. Администратор может заблокировать любого пользователя в разделе Админка → Пользователи."),
            ("Где найти правила и условия?", "Смотрите страницы: «Правила», «Условия», «Политика конфиденциальности» в шапке и подвале сайта."),
        ]
        for i, (q, a) in enumerate(samples, start=1):
            db.add(FaqItem(question=q, answer=a, rank=i, is_public=True))
        db.commit()

from fastapi import status
from app.utils import render as _render_safe

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    # Log to console; in prod use proper logger
    try:
        print("ERROR:", repr(exc))
    except Exception:
        pass
    # Show a graceful page instead of plain 500
    return _render_safe("page_view.html", request,
                        page=type("P", (), {"title": "Внутренняя ошибка", "content": "Произошла ошибка. Мы уже чиним. Попробуйте ещё раз."})(),
                        title="Ошибка",
                        )


# Ensure CMS defaults on startup (idempotent)
from app.models import Page, FaqItem

@app.on_event("startup")
def _seed_default_cms():
    with SessionLocal() as db:
        defaults = {
            "rules": ("Правила площадки", "Здесь будут опубликованы правила использования площадки. Текст‑заглушка."),
            "terms": ("Условия сервиса", "Базовые условия обслуживания. Текст‑заглушка."),
            "privacy": ("Политика конфиденциальности", "Мы ценим вашу приватность. Подробная политика будет опубликована позднее. Текст‑заглушка."),
        }
        for slug, (title, content) in defaults.items():
            p = db.query(Page).filter_by(slug=slug).first()
            if not p:
                db.add(Page(slug=slug, title=title, content=content, is_public=True))
        if db.query(FaqItem).count() == 0:
            samples = [
                ("Как рекрутер берёт в работу заявку?", f"Зайдите в Панель → Заявки и нажмите «Взять в работу». На одну заявку допускается до {MAX_RECRUITERS_PER_JOB} рекрутеров."),
                ("Как отправить резюме/файл?", "Откройте чат по заявке и прикрепите файл через иконку 📎."),
                ("Можно ли заблокировать нарушителя?", "Да. Администратор может заблокировать пользователя в разделе Админка → Пользователи."),
                ("Где найти правила и условия?", "Смотрите страницы: «Правила», «Условия», «Политика конфиденциальности»."),
            ]
            for i, (q, a) in enumerate(samples, start=1):
                db.add(FaqItem(question=q, answer=a, rank=i, is_public=True))
        db.commit()
