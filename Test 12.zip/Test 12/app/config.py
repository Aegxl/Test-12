import os
from pathlib import Path

# Security
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")

# Database
DB_URL = os.getenv("DB_URL", "sqlite:///market.db")

# Upload settings
UPLOAD_DIR = os.path.abspath(os.getenv("UPLOAD_DIR", "uploads"))
Path(UPLOAD_DIR).mkdir(exist_ok=True)

# Email settings
SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT", "0") or 0)
SMTP_USER = os.getenv("SMTP_USER")
SMTP_PASS = os.getenv("SMTP_PASS")
EMAIL_FROM = os.getenv("EMAIL_FROM", "noreply@otvet.kz")

# Telegram settings
TG_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TG_CHAT = os.getenv("TELEGRAM_CHAT_ID")

# Business logic
MAX_RECRUITERS_PER_JOB = int(os.getenv("MAX_RECRUITERS_PER_JOB", "3"))