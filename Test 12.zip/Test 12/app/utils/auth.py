from typing import Tuple
from itsdangerous import TimestampSigner, BadSignature
from fastapi import HTTPException

from app.config import SECRET_KEY

signer = TimestampSigner(SECRET_KEY)


def make_ws_token(uid: int, job_id: int, recruiter_id: int) -> str:
    """Create WebSocket token for chat authentication"""
    payload = f"{uid}:{job_id}:{recruiter_id}"
    return signer.sign(payload.encode()).decode()


def verify_ws_token(token: str) -> Tuple[int, int, int]:
    """Verify WebSocket token and extract user/job/recruiter IDs"""
    try:
        data = signer.unsign(token.encode(), max_age=60*60*24).decode()
        parts = data.split(":")
        if len(parts) != 3:
            raise BadSignature("bad parts")
        uid, job_id, recruiter_id = map(int, parts)
        return uid, job_id, recruiter_id
    except BadSignature:
        raise HTTPException(status_code=401, detail="bad token")