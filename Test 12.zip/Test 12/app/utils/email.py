import smtplib
from email.mime.text import MIMEText
import requests

from app.config import SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, EMAIL_FROM, TG_TOKEN, TG_CHAT


def send_email_safe(to_email: str, subject: str, text: str):
    """Send email safely with error handling"""
    if not (SMTP_HOST and SMTP_PORT and EMAIL_FROM):
        return
    try:
        msg = MIMEText(text, _charset="utf-8")
        msg["Subject"] = subject
        msg["From"] = EMAIL_FROM
        msg["To"] = to_email

        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as s:
            if SMTP_USER and SMTP_PASS:
                try:
                    s.starttls()
                except Exception:
                    pass
                s.login(SMTP_USER, SMTP_PASS)
            s.sendmail(EMAIL_FROM, [to_email], msg.as_string())
    except Exception:
        pass


def send_telegram_safe(text: str):
    """Send Telegram message safely with error handling"""
    if not (TG_TOKEN and TG_CHAT):
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT, "text": text}
        )
    except Exception:
        pass