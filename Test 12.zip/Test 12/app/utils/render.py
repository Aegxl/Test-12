from datetime import datetime
from fastapi import Request
from fastapi.responses import HTMLResponse
from app.database import SessionLocal
from app.dependencies import current_user
from app.templates import get_jinja_env
from app.config import MAX_RECRUITERS_PER_JOB

env = get_jinja_env()

def render(name: str, request: Request, **context) -> HTMLResponse:
    with SessionLocal() as db:
        user = current_user(request, db)
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow(),
        "max_recr": MAX_RECRUITERS_PER_JOB,
        **context
    })
    return HTMLResponse(html)
