import json
import html as _pyhtml
from datetime import datetime
from fastapi import Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from app.models import Event
from app.config import MAX_RECRUITERS_PER_JOB


def escape_html(s: str) -> str:
    """Escape HTML characters"""
    return _pyhtml.escape(s, quote=False)


def fmt_money(value: float) -> str:
    """Format money value with currency"""
    try:
        return f"{value:,.0f} ₸".replace(",", " ")
    except Exception:
        return f"{value} ₸"


def record_event(db: Session, type_: str, **meta):
    """Record an event in the database"""
    e = Event(
        type=type_,
        actor_id=meta.get("actor_id"),
        job_id=meta.get("job_id"),
        recruiter_id=meta.get("recruiter_id"),
        invoice_id=meta.get("invoice_id"),
        meta=json.dumps(meta, ensure_ascii=False)
    )
    db.add(e)
    db.commit()


def render_template(env, name: str, request: Request, user=None, **context) -> HTMLResponse:
    """Common render function for all routes"""
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow(),
        "max_recr": MAX_RECRUITERS_PER_JOB,
        **context
    })
    return HTMLResponse(html)