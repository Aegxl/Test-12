from datetime import datetime
from .auth import make_ws_token, verify_ws_token
from .email import send_email_safe, send_telegram_safe
from .helpers import escape_html, fmt_money, record_event, render_template

__all__ = [
    "make_ws_token",
    "verify_ws_token",
    "send_email_safe",
    "send_telegram_safe",
    "escape_html",
    "fmt_money",
    "record_event",
    "render_template"
]

from app.templates import get_jinja_env
from fastapi import Request
from fastapi.responses import HTMLResponse

def render(name: str, request: Request, user=None, **context) -> HTMLResponse:
    """Convenience wrapper used by routes. Prevents AttributeErrors when importing.
    Uses in-memory Jinja templates declared in app/templates/*.
    """
    env = get_jinja_env()
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow() if 'datetime' in globals() else None,
        **context
    })
    return HTMLResponse(html)
