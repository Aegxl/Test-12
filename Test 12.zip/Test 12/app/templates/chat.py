CHAT_TEMPLATES = {
    "chat.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto card animate-fadeUp">
    <div class="flex items-center justify-between mb-4">
      <div>
        <div class="text-sm text-gray-500">Вакансия</div>
        <h1 class="text-xl font-semibold">{{ job.title }}</h1>
        <div class="text-gray-500 text-sm">Собеседники: {{ employer.name }} ↔ {{ recruiter.name }}</div>
      </div>
      <a class="btn btn-light" href="/dashboard">Назад</a>
    </div>

    <div id="messages" class="border rounded-xl p-3 h-80 overflow-y-auto bg-gray-50"></div>

    <form id="chat-form" class="mt-4 flex gap-2">
      <input id="msg" type="text" class="flex-1 border rounded-xl p-2" placeholder="Сообщение..." required />
      <label class="btn btn-light cursor-pointer">
        📎
        <input id="file" type="file" class="hidden" />
      </label>
      <button class="btn btn-primary" type="submit">Отправить</button>
    </form>
  </div>

  <script>
    const wsToken = "{{ ws_token }}";
    const wsUrl = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws?token=${encodeURIComponent(wsToken)}`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      const data = event.data;
      const box = document.getElementById('messages');
      const div = document.createElement('div');
      div.className = 'mb-2';
      div.innerHTML = data;
      box.appendChild(div);
      box.scrollTop = box.scrollHeight;
    };

    function escapeHtml(str){
      return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    document.getElementById('chat-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = document.getElementById('msg');
      const fileInput = document.getElementById('file');
      const msg = input.value.trim();
      if(fileInput.files.length > 0){
        const f = fileInput.files[0];
        const fd = new FormData();
        fd.append('file', f);
        const res = await fetch(`/api/chat/{{ job.id }}/{{ recruiter.id }}/upload`, {method:'POST', body: fd});
        const data = await res.json();
        if(data.ok){
          socket.send(JSON.stringify({type:'message', content: data.placeholder}));
          fileInput.value = '';
        }
        return;
      }
      if(!msg) return;
      socket.send(JSON.stringify({type:'message', content: msg}));
      input.value = '';
    });

    (async function init(){
      const res = await fetch(`/api/chat/{{ job.id }}/{{ recruiter.id }}/list`);
      const html = await res.text();
      const box = document.getElementById('messages');
      box.innerHTML = html;
      box.scrollTop = box.scrollHeight;
    })();
  </script>
{% endblock %}
"""
}