ADMIN_TEMPLATES = {
    "admin.html": r"""
{% extends 'base.html' %}
{% block content %}
  <h1 class="text-2xl font-semibold mb-4">Админ-панель</h1>
  <div class="grid md:grid-cols-2 gap-6">
    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Ожидают модерации</h2>
      {% for j in pending_jobs %}
        <div class="flex items-center justify-between border-b py-2">
          <div>
            <div class="font-medium">{{ j.title }}</div>
            <div class="text-sm text-gray-500">{{ j.city or '—' }} {{ j.is_remote and '(Дистанционная работа)' or '' }} • {{ j.level or '—' }} • {{ j.reward_fmt }}</div>
          </div>
          <div class="space-x-2">
            <form method="post" action="/admin/job/{{ j.id }}/approve" class="inline"><button class="btn btn-primary">Одобрить</button></form>
            <form method="post" action="/admin/job/{{ j.id }}/reject" class="inline"><button class="btn btn-light">Отклонить</button></form>
          </div>
        </div>
      {% else %}
        <div class="text-sm text-gray-500">Нет новых заявок.</div>
      {% endfor %}
    </div>

    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Пользователи</h2>
      {% for u in users %}
        <div class="flex items-center justify-between border-b py-2">
          <div>
            <div class="font-medium">{{ u.name }}</div>
            <div class="text-sm text-gray-500">{{ u.email }} • {{ u.role }} • {{ u.is_active and 'активен' or 'заблокирован' }}</div>
          </div>
          <div class="space-x-2">
            {% if u.is_active %}
              <form method="post" action="/admin/user/{{ u.id }}/block" class="inline"><button class="btn btn-light">Заблокировать</button></form>
            {% else %}
              <form method="post" action="/admin/user/{{ u.id }}/unblock" class="inline"><button class="btn btn-primary">Разблокировать</button></form>
            {% endif %}
          </div>
        </div>
      {% endfor %}
    </div>
  </div>

  <div class="grid md:grid-cols-2 gap-6 mt-6">
    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Инвойсы</h2>
      <form method="post" action="/admin/invoices/new" class="grid md:grid-cols-4 gap-3 mb-4">
        <select class="border rounded-xl p-2" name="employer_id" required>
          <option value="">Работодатель…</option>
          {% for e in employers %}
            <option value="{{ e.id }}">{{ e.name }} ({{ e.email }})</option>
          {% endfor %}
        </select>
        <input class="border rounded-xl p-2" type="number" step="1" min="0" name="amount" placeholder="Сумма, ₸" required />
        <input class="border rounded-xl p-2" type="text" name="description" placeholder="Описание" />
        <button class="btn btn-primary" type="submit">Выставить</button>
      </form>
      <div class="space-y-2">
        {% for inv in invoices %}
          <div class="flex items-center justify-between border-b py-2">
            <div>
              <div class="font-medium">#{{ inv.id }} — {{ inv.amount|int }} {{ inv.currency }} ({{ inv.status }})</div>
              <div class="text-sm text-gray-500">{{ inv.employer.name }} • {{ inv.description or '—' }}</div>
            </div>
            <div class="space-x-2">
              {% if inv.status!='paid' %}
                <form method="post" action="/admin/invoices/{{ inv.id }}/mark-paid" class="inline"><button class="btn btn-light">Отметить как оплаченный</button></form>
              {% endif %}
            </div>
          </div>
        {% else %}
          <div class="text-sm text-gray-500">Пока нет инвойсов.</div>
        {% endfor %}
      </div>
    </div>

    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Страницы (CMS)</h2>
      <div class="mb-3">
        <a class="btn btn-primary" href="/admin/pages/new">+ Новая страница</a>
        <a class="btn btn-light" href="/admin/faq">FAQ</a>
      </div>
      {% for p in pages %}
        <div class="flex items-center justify-between border-b py-2">
          <div>
            <div class="font-medium">{{ p.title }}</div>
            <div class="text-sm text-gray-500">/{{ p.slug }} • {{ p.is_public and 'публична' or 'скрыта' }} • обновлено {{ p.updated_at.strftime('%d.%m %H:%M') }}</div>
          </div>
          <div class="space-x-2">
            <a class="btn btn-light" href="/page/{{ p.slug }}" target="_blank">Открыть</a>
            <a class="btn btn-light" href="/admin/pages/{{ p.id }}/edit">Править</a>
          </div>
        </div>
      {% else %}
        <div class="text-sm text-gray-500">Пока нет страниц.</div>
      {% endfor %}
    </div>
  </div>
{% endblock %}
"""
,
    "admin_users.html": r"""
{% extends 'base.html' %}
{% block content %}
  <h1 class="text-2xl font-semibold mb-4">Пользователи</h1>
  <div class="card">
    {% for u in users %}
      <div class="flex items-center justify-between py-2 border-b">
        <div>
          <div class="font-medium">{{ u.name }} <span class="text-xs badge">{{ u.role }}</span></div>
          <div class="text-sm text-gray-600">{{ u.email }} • Создан: {{ u.created_at.strftime('%d.%m.%Y %H:%M') if u.created_at else '—' }}</div>
        </div>
        <div class="space-x-2">
          {% if u.is_active %}
          <form method="post" action="/admin/users/{{ u.id }}/block" class="inline">
            <button class="btn btn-light" onclick="return confirm('Заблокировать пользователя?')">Блокировать</button>
          </form>
          {% else %}
          <form method="post" action="/admin/users/{{ u.id }}/unblock" class="inline">
            <button class="btn btn-primary">Разблокировать</button>
          </form>
          {% endif %}
        </div>
      </div>
    {% else %}
      <div class="text-sm text-gray-500">Пока пусто.</div>
    {% endfor %}
  </div>
{% endblock %}
"""

}
