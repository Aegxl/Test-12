DASHBOARD_TEMPLATES = {
    "dashboard_employer.html": r"""
{% set pending_count = (jobs | selectattr("status","equalto","pending") | list | length) %}

{% extends 'base.html' %}
{% block content %}
  <div class="flex items-center justify-between mb-4">
    <h1 id="jobs" class="text-2xl font-semibold">Мои заявки</h1>
    <a class="btn btn-primary" href="/jobs/new">+ Новая заявка</a>
  </div>
  <div class="grid gap-4">
    {% if pending_count > 0 %}
      <div class="card bg-yellow-50">
        <div class="font-semibold mb-1">У вас {{ pending_count }} заявка(и) на модерации</div>
        <div class="text-sm text-gray-700">Как только модерация одобрит — заявка станет видна рекрутерам.</div>
      </div>
    {% endif %}
    {% for job in jobs %}
      <div class="card reveal">
        <div class="flex items-center justify-between">
          <div>
            <div class="text-lg font-semibold">{{ job.title }}</div>
            <div class="text-gray-600">Вознаграждение: <strong>{{ job.reward_fmt }}</strong></div>
            <div class="text-gray-500 text-sm">Статус: {{ job.status|capitalize }} • {{ job.city or '—' }} {{ job.is_remote and '(Дистанционная работа)' or '' }} • {{ job.level or '—' }}</div>
            {% if job.tags %}<div class="text-xs text-gray-500">Теги: {{ job.tags }}</div>{% endif %}
            <div class="text-gray-500 text-sm">Создана: {{ job.created_at.strftime('%d.%m.%Y %H:%M') }}</div>
          </div>
          <div class="space-x-2">
            <a class="btn btn-light" href="/jobs/{{ job.id }}">Подробнее</a>
          </div>
        </div>
      </div>
    {% else %}
      <div class="text-gray-500">Пока нет заявок.</div>
    {% endfor %}
  </div>

  <div class="mt-8">
    <h2 class="text-xl font-semibold mb-2">События</h2>
    <div class="space-y-2">
      {% for e in events %}
        <div class="text-sm text-gray-600">• {{ e.created_at.strftime('%d.%m %H:%M') }} — {{ e.text }}</div>
      {% else %}
        <div class="text-gray-400 text-sm">Пока пусто.</div>
      {% endfor %}
    </div>
  </div>
{% endblock %}
""",

    "dashboard_recruiter.html": r"""
{% extends 'base.html' %}
{% block content %}
  <form class="card mb-6 grid md:grid-cols-5 gap-3" method="get">
    <div>
      <label class="text-xs text-gray-500">Город</label>
      <input class="w-full border rounded-xl p-2" type="text" name="city" value="{{ filters.city }}" />
    </div>
    <div>
      <label class="text-xs text-gray-500">Уровень</label>
      <select class="w-full border rounded-xl p-2" name="level">
        <option value="">Любой</option>
        {% for lv in ['junior','middle','senior'] %}
          <option value="{{ lv }}" {% if filters.level==lv %}selected{% endif %}>{{ lv }}</option>
        {% endfor %}
      </select>
    </div>
    <div class="flex items-end">
      <label class="inline-flex items-center gap-2">
        <input type="checkbox" name="remote" value="1" {% if filters.remote %}checked{% endif %} /> Дистанционная работа
      </label>
    </div>
    <div class="md:col-span-2">
      <label class="text-xs text-gray-500">Теги (через запятую)</label>
      <input class="w-full border rounded-xl p-2" type="text" name="tags" value="{{ filters.tags }}" />
    </div>
    <div class="md:col-span-5 flex justify-end">
      <button class="btn btn-light" type="submit">Фильтровать</button>
    </div>
  </form>

  <div class="grid md:grid-cols-2 gap-6">
    <div>
      <h2 id="jobs" class="text-xl font-semibold mb-2">Доступные заявки</h2>
      <div class="space-y-4">
        {% for job in open_jobs %}
          <div class="card reveal">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-lg font-semibold">{{ job.title }}</div>
                <div class="text-gray-600">{{ job.city or '—' }} {{ job.is_remote and '(Дистанционная работа)' or '' }} • {{ job.level or '—' }}</div>
                {% if job.tags %}<div class="text-xs text-gray-500">Теги: {{ job.tags }}</div>{% endif %}
                <div class="text-gray-600">Вознаграждение: <strong>{{ job.reward_fmt }}</strong></div>
                <div class="text-gray-500 text-sm">Свободно мест: {{ job.free_slots }} из {{ max_recr }}</div>
              </div>
              <form method="post" action="/jobs/{{ job.id }}/take">
                <button class="btn btn-primary" {% if job.free_slots==0 %}disabled{% endif %}>Взяться</button>
              </form>
            </div>
          </div>
        {% else %}
          <div class="text-gray-500">Нет подходящих заявок.</div>
        {% endfor %}
      </div>
    </div>
    <div>
      <h2 id="chats" class="text-xl font-semibold mb-2">Мои вакансии</h2>
      <div class="space-y-4">
        {% for a in my_assignments %}
          <div class="card reveal">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-lg font-semibold">{{ a.job.title }}</div>
                <div class="text-gray-600">Работодатель: {{ a.job.employer.name }}</div>
                <div class="text-gray-500 text-sm">Статус подбора: {{ a.pipeline_status }}</div>
                <div class="text-gray-500 text-sm">Назначен: {{ a.assigned_at.strftime('%d.%m.%Y %H:%M') }}</div>
              </div>
              <div class="space-x-2">
                <a class="btn btn-light" href="/chat/{{ a.job.id }}/{{ user.id }}">Чат</a>
                <form method="post" action="/assign/{{ a.id }}/stage" class="inline">
                  <select class="border rounded-xl p-1" name="stage" onchange="this.form.submit()">
                    {% for st in ['приглашён','интервью','оффер','закрыто'] %}
                      <option value="{{ st }}" {% if a.pipeline_status==st %}selected{% endif %}>{{ st }}</option>
                    {% endfor %}
                  </select>
                </form>
              </div>
            </div>
          </div>
        {% else %}
          <div class="text-gray-500">Вы ещё не взялись ни за одну заявку.</div>
        {% endfor %}
      </div>
    </div>
  </div>

  <div class="mt-8">
    <h2 class="text-xl font-semibold mb-2">События</h2>
    <div class="space-y-2">
      {% for e in events %}
        <div class="text-sm text-gray-600">• {{ e.created_at.strftime('%d.%m %H:%M') }} — {{ e.text }}</div>
      {% else %}
        <div class="text-gray-400 text-sm">Пока пусто.</div>
      {% endfor %}
    </div>
  </div>
{% endblock %}
"""
}