AUTH_TEMPLATES = {
    "auth_login.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-md mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">Вход</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Email
        <input class="w-full border rounded-xl p-2" type="email" name="email" required />
      </label>
      <label class="block mb-4">Пароль
        <input class="w-full border rounded-xl p-2" type="password" name="password" required />
      </label>
      <button class="btn btn-primary w-full" type="submit">Войти</button>
    </form>
  </div>
{% endblock %}
""",

    "auth_register.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-md mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">Регистрация</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Имя
        <input class="w-full border rounded-xl p-2" type="text" name="name" required />
      </label>
      <label class="block mb-2">Email
        <input class="w-full border rounded-xl p-2" type="email" name="email" required />
      </label>
      <label class="block mb-2">Пароль
        <input class="w-full border rounded-xl p-2" type="password" name="password" required />
      </label>
      <label class="block mb-2">Роль
        <select class="w-full border rounded-xl p-2" name="role" required>
          <option value="employer" {% if pref_role=='employer' %}selected{% endif %}>Работодатель</option>
          <option value="recruiter" {% if pref_role=='recruiter' %}selected{% endif %}>Рекрутер</option>
        </select>
      </label>

      <label class="block mb-4">
        <input type="checkbox" name="accept_terms" value="1" required />
        Я принимаю <a href="/page/terms" class="link">Условия</a> и <a href="/page/privacy" class="link">Политику конфиденциальности</a>
      </label>

      <button class="btn btn-primary w-full" type="submit">Создать аккаунт</button>
    </form>
  </div>
{% endblock %}
"""
}