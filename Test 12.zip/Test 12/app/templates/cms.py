CMS_TEMPLATES = {
    "page_view.html": r"""
{% extends 'base.html' %}
{% block content %}
  <article class="max-w-3xl mx-auto card animate-fadeUp">
    <h1 class="text-2xl font-semibold mb-2">{{ page.title }}</h1>
    <div class="prose prose-sm max-w-none whitespace-pre-line">{{ page.content }}</div>
  </article>
{% endblock %}
""",

    "pages_admin_list.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-semibold">Страницы</h1>
    <a class="btn btn-primary" href="/admin/pages/new">+ Новая страница</a>
  </div>
  <div class="card">
    {% for p in pages %}
      <div class="flex items-center justify-between border-b py-2">
        <div>
          <div class="font-medium">{{ p.title }}</div>
          <div class="text-sm text-gray-500">/{{ p.slug }} • {{ p.is_public and 'публична' or 'скрыта' }}</div>
        </div>
        <div class="space-x-2">
          <a class="btn btn-light" href="/page/{{ p.slug }}" target="_blank">Открыть</a>
          <a class="btn btn-light" href="/admin/pages/{{ p.id }}/edit">Править</a>
        </div>
      </div>
    {% else %}
      <div class="text-sm text-gray-500">Пока нет страниц.</div>
    {% endfor %}
  </div>
{% endblock %}
""",

    "page_edit.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">{{ page and 'Правка страницы' or 'Новая страница' }}</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Slug (латиница, напр. rules/terms/privacy/about)
        <input class="w-full border rounded-xl p-2" type="text" name="slug" value="{{ page and page.slug or '' }}" required />
      </label>
      <label class="block mb-2">Заголовок
        <input class="w-full border rounded-xl p-2" type="text" name="title" value="{{ page and page.title or '' }}" required />
      </label>
      <label class="block mb-4">Содержимое (ваш текст)
        <textarea class="w-full border rounded-xl p-2" name="content" rows="12">{{ page and page.content or '' }}</textarea>
      </label>
      <div class="flex items-center gap-4">
        <label><input type="checkbox" name="is_public" value="1" {% if not page or page.is_public %}checked{% endif %}/> Публичная</label>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        {% if page %}
          <form method="post" action="/admin/pages/{{ page.id }}/delete" onsubmit="return confirm('Удалить страницу?')" class="inline">
            <button class="btn btn-light" type="submit">Удалить</button>
          </form>
        {% endif %}
      </div>
    </form>
  </div>
{% endblock %}
""",

    "faq_public.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto space-y-4">
    <h1 class="text-2xl font-semibold">FAQ — Частые вопросы</h1>
    {% for f in items %}
      <div class="card reveal">
        <div class="font-semibold mb-2">{{ loop.index }}. {{ f.question }}</div>
        <div class="text-gray-700 whitespace-pre-line">{{ f.answer }}</div>
      </div>
    {% else %}
      <div class="text-gray-500">Пока нет вопросов.</div>
    {% endfor %}
  </div>
{% endblock %}
""",

    "faq_admin.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-semibold">FAQ</h1>
    <a class="btn btn-primary" href="/admin/faq/new">+ Новый вопрос</a>
  </div>
  <div class="space-y-3">
    {% for f in items %}
      <div class="card">
        <div class="flex items-start justify-between gap-4">
          <div>
            <div class="text-sm text-gray-500">#{{ f.id }} • {{ f.is_public and 'опубликован' or 'скрыт' }} • порядок {{ f.rank }}</div>
            <div class="font-semibold mb-2">{{ f.question }}</div>
            <div class="text-gray-700 whitespace-pre-line">{{ f.answer }}</div>
          </div>
          <div class="space-x-2">
            <a class="btn btn-light" href="/admin/faq/{{ f.id }}/edit">Править</a>
            <form method="post" action="/admin/faq/{{ f.id }}/delete" onsubmit="return confirm('Удалить?')" class="inline"><button class="btn btn-light">Удалить</button></form>
          </div>
        </div>
      </div>
    {% else %}
      <div class="text-gray-500">Пока пусто.</div>
    {% endfor %}
  </div>
{% endblock %}
""",

    "faq_edit.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">{{ item and 'Правка вопроса' or 'Новый вопрос' }}</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Вопрос
        <input class="w-full border rounded-xl p-2" type="text" name="question" value="{{ item and item.question or '' }}" required />
      </label>
      <label class="block mb-4">Ответ
        <textarea class="w-full border rounded-xl p-2" name="answer" rows="10" required>{{ item and item.answer or '' }}</textarea>
      </label>
      <div class="grid md:grid-cols-3 gap-4 mb-4">
        <label>Порядок <input class="w-full border rounded-xl p-2" type="number" name="rank" value="{{ item and item.rank or 0 }}" /></label>
        <label class="flex items-center gap-2"><input type="checkbox" name="is_public" value="1" {% if not item or item.is_public %}checked{% endif %}/> Опубликовать</label>
      </div>
      <button class="btn btn-primary" type="submit">Сохранить</button>
    </form>
  </div>
{% endblock %}
"""
}