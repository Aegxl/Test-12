JOB_TEMPLATES = {
    "job_new.html": r"""

{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">Новая заявка</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form id="jobForm" method="post">
      <label class="block mb-3">Название позиции
        <input class="w-full border rounded-xl p-2" type="text" name="title" required />
      </label>

      <label class="block mb-3">Краткое описание (2–3 предложения)
        <textarea class="w-full border rounded-xl p-2" name="description" rows="3" placeholder="Кто нужен, зачем и ключевые задачи" required></textarea>
      </label>

      <div class="grid md:grid-cols-3 gap-4">
        <label class="block">Город
          <input class="w-full border rounded-xl p-2" type="text" name="city" placeholder="Алматы / Астана / др." />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт — можно оставить пустым)</div>
        </label>

        <label class="block">Формат работы
          <select class="w-full border rounded-xl p-2" name="work_format">
            <option value="office">Офис</option>
            <option value="hybrid">Гибрид</option>
            <option value="remote">Дистанционная работа</option>
          </select>
        </label>

        <label class="block">Уровень
          <select class="w-full border rounded-xl p-2" name="level">
            <option value="">Не указан</option>
            <option value="junior">Junior</option>
            <option value="middle">Middle</option>
            <option value="senior">Senior</option>
          </select>
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
      </div>

      <div class="grid md:grid-cols-3 gap-4 mt-4">
        <label class="block">Вознаграждение рекрутеру (₸)
          <input class="w-full border rounded-xl p-2" type="number" name="reward" min="0" step="1000" placeholder="напр., 150000" required />
        </label>

        <label class="block">Зарплата: от (₸)
          <input class="w-full border rounded-xl p-2" type="number" name="salary_from" min="0" step="1000" placeholder="опционально" />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>

        <label class="block">Зарплата: до (₸)
          <input class="w-full border rounded-xl p-2" type="number" name="salary_to" min="0" step="1000" placeholder="опционально" />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
      </div>

      <div class="grid md:grid-cols-2 gap-4 mt-4">
        <label class="block">Тип занятости
          <select class="w-full border rounded-xl p-2" name="employment_type">
            <option value="">Не указан</option>
            <option>Полная занятость</option>
            <option>Частичная занятость</option>
            <option>Проектная работа</option>
            <option>Стажировка</option>
            <option>Гибкий график</option>
          </select>
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>

        <label class="block">Срок выхода
          <select class="w-full border rounded-xl p-2" name="start_timing">
            <option value="">Не указан</option>
            <option>Как можно скорее</option>
            <option>В течение 2 недель</option>
            <option>В течение 1 месяца</option>
            <option>Обсуждается</option>
          </select>
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
      </div>

      <div class="grid md:grid-cols-2 gap-4 mt-4">
        <label class="block">Требуемый опыт (лет)
          <input class="w-full border rounded-xl p-2" type="number" name="experience_years" min="0" max="50" placeholder="опционально" />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>

        <label class="block">Образование
          <input class="w-full border rounded-xl p-2" type="text" name="education" placeholder="опционально" />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
      </div>

      <label class="block mt-4">Ключевые обязанности
        <textarea class="w-full border rounded-xl p-2" name="responsibilities" rows="4" placeholder="маркированным списком; можно оставить пустым"></textarea>
        <div class="text-xs text-gray-500 mt-1">(необязательный пункт — можно оставить пустым)</div>
      </label>

      <label class="block mt-4">Требования (hard/soft)
        <textarea class="w-full border rounded-xl p-2" name="requirements" rows="4" placeholder="маркированным списком; можно оставить пустым"></textarea>
        <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
      </label>

      <label class="block mt-4">Преимущества/бонусы работодателя
        <textarea class="w-full border rounded-xl p-2" name="benefits" rows="3" placeholder="ДМС, обучение, бонусы и т.п. (опционально)"></textarea>
        <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
      </label>

      <div class="grid md:grid-cols-2 gap-4 mt-4">
        <label class="block">Иностранные языки
          <input class="w-full border rounded-xl p-2" type="text" name="languages" placeholder="например: русский, казахский, английский B2" />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
        <label class="block">Инструменты/техстек
          <input class="w-full border rounded-xl p-2" type="text" name="tech_stack" placeholder="CRM, 1C, Excel, Python и т.д." />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
      </div>

      <div class="grid md:grid-cols-3 gap-4 mt-4">
        <label class="block">Количество кандидатов
          <input class="w-full border rounded-xl p-2" type="number" name="headcount" min="1" step="1" placeholder="1" />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
        <label class="block">Дедлайн подбора
          <input class="w-full border rounded-xl p-2" type="date" name="deadline" />
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
        <label class="block">Приоритет
          <select class="w-full border rounded-xl p-2" name="priority">
            <option value="">Обычный</option>
            <option>Высокий</option>
            <option>Низкий</option>
          </select>
          <div class="text-xs text-gray-500 mt-1">(необязательный пункт)</div>
        </label>
      </div>

      <div class="grid md:grid-cols-3 gap-4 mt-4">
        <label class="inline-flex items-center gap-2">
          <input type="checkbox" name="nda_required" value="1" />
          <span>Требуется NDA</span>
        </label>
        <label class="inline-flex items-center gap-2">
          <input type="checkbox" name="travel" value="1" />
          <span>Командировки</span>
        </label>
        <label class="inline-flex items-center gap-2">
          <input type="checkbox" name="drivers_license" value="1" />
          <span>Водительское удостоверение</span>
        </label>
      </div>

      <label class="block mt-4">Дополнительные пожелания
        <textarea class="w-full border rounded-xl p-2" name="notes" rows="3" placeholder="любой текст; можно оставить пустым"></textarea>
        <div class="text-xs text-gray-500 mt-1">(необязательный пункт — можно оставить пустым)</div>
      </label>

      <!-- Backend fields expected by existing route -->
      <input type="hidden" name="is_remote" id="is_remote" value="0" />
      <input type="hidden" name="tags" id="tags" value="" />

      <div class="mt-6 flex gap-3">
        <button class="btn btn-primary" type="submit">Отправить на модерацию</button>
        <a class="btn btn-light" href="/dashboard">Отмена</a>
      </div>
    
      <hr class="my-6"/>

      <div class="grid md:grid-cols-2 gap-4">
        <label class="block">Тип занятости <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <select class="w-full border rounded-xl p-2" name="employment_type">
            <option value="">— оставить пустым —</option>
            <option>Полная занятость</option>
            <option>Частичная занятость</option>
            <option>Проектная/временная</option>
            <option>Контракт</option>
            <option>Стажировка</option>
          </select>
        </label>

        <label class="block">Формат работы <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <select class="w-full border rounded-xl p-2" name="remote_type">
            <option value="">— оставить пустым —</option>
            <option>Офис</option>
            <option>Гибрид</option>
            <option>Дистанционная работа</option>
          </select>
        </label>

        <label class="block">График работы <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="text" name="schedule" placeholder="Например: Пн–Пт, 9:00–18:00" />
        </label>

        <label class="block">Количество открытых позиций <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="number" name="openings" min="1" placeholder="— можно оставить пустым —" />
        </label>

        <label class="block">Требуемый опыт, лет <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="number" name="experience_years" min="0" step="1" placeholder="— оставить пустым —" />
        </label>

        <label class="block">Образование <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="text" name="education" placeholder="— оставить пустым —" />
        </label>

        <label class="block">Иностранные языки <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="text" name="languages" placeholder="Например: Русский C1, Казахский B2, Английский B1" />
        </label>

        <label class="block">Испытательный срок <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="text" name="probation" placeholder="Например: 3 месяца" />
        </label>

        <label class="block">Дедлайн закрытия позиции <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="date" name="deadline" />
        </label>

        <label class="block">Контактный e‑mail <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="email" name="contact_email" placeholder="— оставить пустым —" />
        </label>

        <label class="block">Контактный телефон <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="tel" name="contact_phone" placeholder="— оставить пустым —" />
        </label>

        <label class="block md:col-span-2">Адрес офиса (для офиса/гибрида) <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <input class="w-full border rounded-xl p-2" type="text" name="office_address" placeholder="— оставить пустым —" />
        </label>

        <label class="block md:col-span-2">Комментарий/доп. условия <span class="text-gray-400 text-xs">(необязательный пункт)</span>
          <textarea class="w-full border rounded-xl p-2" name="notes" rows="3" placeholder="Любые нюансы по KPI, бонусам, режиму, командировкам и т.д."></textarea>
        </label>
      </div>

      <p class="text-sm text-gray-500 mt-3">Поля, отмеченные как «необязательный пункт», можно не заполнять.</p>

      </form>
  </div>

  <script>
    // Convert work_format -> is_remote and collect extra criteria into tags
    const form = document.getElementById('jobForm');
    form.addEventListener('submit', (e) => {
      const wf = form.elements['work_format']?.value || 'office';
      const isRemote = (wf === 'remote') ? '1' : '0';
      form.elements['is_remote'].value = isRemote;

      const kv = [];
      const push = (k, v) => { if (v && String(v).trim() !== '') kv.push(`${k}:${String(v).trim()}`); };

      push('work_format', wf);
      push('employment', form.elements['employment_type']?.value);
      push('salary_from', form.elements['salary_from']?.value);
      push('salary_to', form.elements['salary_to']?.value);
      push('start', form.elements['start_timing']?.value);
      push('exp_years', form.elements['experience_years']?.value);
      push('education', form.elements['education']?.value);
      push('languages', form.elements['languages']?.value);
      push('tech', form.elements['tech_stack']?.value);
      push('headcount', form.elements['headcount']?.value);
      push('deadline', form.elements['deadline']?.value);
      push('priority', form.elements['priority']?.value);
      push('nda', form.elements['nda_required']?.checked ? 'yes' : '');
      push('travel', form.elements['travel']?.checked ? 'yes' : '');
      push('driver', form.elements['drivers_license']?.checked ? 'yes' : '');

      // Encode multiline blocks into tags-shortcuts
      const shortText = (name) => (form.elements[name]?.value || '').split('\\n').slice(0,4).join('; ').slice(0,200);
      push('req', shortText('requirements'));
      push('resp', shortText('responsibilities'));
      push('benefits', shortText('benefits'));

      // Merge with existing tags if any visible input exists
      const tagsInput = form.querySelector('input[name="tags"]');
      const existing = tagsInput?.value ? [tagsInput.value] : [];
      tagsInput.value = existing.concat(kv).filter(Boolean).join(', ');
    });
  </script>
{% endblock %}

"""
,
    "job_detail.html": r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto space-y-4">
    {% if request.query_params.get('created') %}
      <div class="card bg-green-50">
        <div class="font-semibold mb-1">Ваша заявка отправлена на модерацию</div>
        <div class="text-sm text-gray-700">Модератор проверит корректность данных и опубликует заявку. Вы получите уведомление.</div>
      </div>
    {% endif %}

    {% if job.status == 'pending' %}
      <div class="card bg-yellow-50">
        <div class="font-semibold mb-1">Заявка на рассмотрении у модерации</div>
        <div class="text-sm text-gray-700">Пока заявка не опубликована, рекрутеры её не видят.</div>
      </div>
    {% endif %}

    <div class="card reveal">
      <div class="flex items-start justify-between gap-4">
        <div>
          <h1 class="text-2xl font-semibold mb-1">{{ job.title }}</h1>
          <div class="text-sm text-gray-600">
            {{ job.city or '—' }} • {{ job.level or '—' }} •
            {% if job.is_remote %}Дистанционная работа{% else %}Офис/Гибрид{% endif %}
            • Вознаграждение: <strong>{{ job.reward_fmt }}</strong>
          </div>
        </div>
        <div class="text-right">
          <span class="badge">{{ job.status }}</span>
        </div>
      </div>
      <hr class="my-4"/>
      <div class="prose prose-sm max-w-none whitespace-pre-line">{{ job.description }}</div>
    </div>

    <div class="flex gap-3">
      <a href="/dashboard" class="btn btn-light"><i data-lucide="arrow-left"></i>&nbsp;В панель</a>
      {% if can_toggle %}
        <form method="post" action="/jobs/{{ job.id }}/toggle">
          <button class="btn btn-primary" type="submit">
            {% if job.status == 'open' %}<i data-lucide="pause"></i>&nbsp;Снять с публикации{% else %}<i data-lucide="play"></i>&nbsp;Опубликовать{% endif %}
          </button>
        </form>
      {% endif %}
    </div>
  </div>
{% endblock %}
"""

}
