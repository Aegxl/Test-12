BASE_TEMPLATES = {
    "base.html": r"""
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{{ title or 'HR Team' }}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      // Icons
      if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}

      // Dark mode
      const root = document.documentElement;
      const key = 'hrteam_theme';
      const btn = document.getElementById('themeToggle');
      const setTheme = (mode)=>{
        if(mode==='dark'){ root.setAttribute('data-theme','dark'); document.body.setAttribute('data-theme','dark'); btn && (btn.innerHTML='<i data-lucide="sun"></i>'); }
        else{ root.removeAttribute('data-theme'); document.body.removeAttribute('data-theme'); btn && (btn.innerHTML='<i data-lucide="moon"></i>'); }
        if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}
        localStorage.setItem(key, mode);
      };
      setTheme(localStorage.getItem(key) || 'light');
      if(btn){ btn.addEventListener('click', ()=>{
        const mode = root.getAttribute('data-theme')==='dark' ? 'light' : 'dark';
        setTheme(mode);
      }); }

      // Quick skeleton overlay on cards (brief, non-blocking)
      const cards = document.querySelectorAll('.card');
      cards.forEach(c=>{
        const overlay = document.createElement('div');
        overlay.className = 'skeleton-overlay';
        c.appendChild(overlay);
        setTimeout(()=>overlay.remove(), 320);
      });
      // Mobile nav toggle
      const navBtn = document.getElementById('navToggle');
      const nav = document.getElementById('mainNav');
      if(navBtn && nav){ navBtn.addEventListener('click', ()=>{ nav.classList.toggle('hidden'); }); }
    });
  </script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      // Icons
      if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}

      // Dark mode
      const root = document.documentElement;
      const key = 'hrteam_theme';
      const btn = document.getElementById('themeToggle');
      const setTheme = (mode)=>{
        if(mode==='dark'){ root.setAttribute('data-theme','dark'); document.body.setAttribute('data-theme','dark'); btn && (btn.innerHTML='<i data-lucide="sun"></i>'); }
        else{ root.removeAttribute('data-theme'); document.body.removeAttribute('data-theme'); btn && (btn.innerHTML='<i data-lucide="moon"></i>'); }
        if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}
        localStorage.setItem(key, mode);
      };
      setTheme(localStorage.getItem(key) || 'light');
      if(btn){ btn.addEventListener('click', ()=>{
        const mode = root.getAttribute('data-theme')==='dark' ? 'light' : 'dark';
        setTheme(mode);
      });

      // Quick skeleton overlay on cards (brief, non-blocking)
      const cards = document.querySelectorAll('.card');
      cards.forEach(c=>{
        const overlay = document.createElement('div');
        overlay.className = 'skeleton-overlay';
        c.appendChild(overlay);
        setTimeout(()=>overlay.remove(), 320);
      });
      // Mobile nav toggle
      const navBtn = document.getElementById('navToggle');
      const nav = document.getElementById('mainNav');
      if(navBtn && nav){ navBtn.addEventListener('click', ()=>{ nav.classList.toggle('hidden'); }); }
    });
  </script>
  
  <style>
    :root{
      --hrt-bg1: #f8fafc;
      --hrt-bg2: #eef2ff;
      --hrt-brand: #4f46e5;
      --hrt-brand-2: #7c3aed;
      --hrt-text: #0f172a;
      --hrt-muted: #64748b;
      --hrt-card: rgba(255,255,255,0.92);
      --hrt-ring: rgba(99,102,241,.35);
    }
    html, body {height:100%}
    body{
      background:
        radial-gradient(1200px 600px at 10% -10%, var(--hrt-bg2), transparent 60%),
        radial-gradient(1200px 600px at 110% 10%, #fde68a33, transparent 60%),
        linear-gradient(180deg, var(--hrt-bg1), #ffffff);
      color: var(--hrt-text);
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
    /* Dark theme variables */
    html[data-theme="dark"], body[data-theme="dark"]{
      --hrt-bg1: #0b1020;
      --hrt-bg2: #111827;
      --hrt-text: #e5e7eb;
      --hrt-muted: #9ca3af;
      --hrt-card: rgba(17,24,39,0.85);
      --hrt-ring: rgba(99,102,241,.45);
    }
    /* Fallback styles for utility classes used in markup */
    .card{ position: relative;
      background: var(--hrt-card);
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(2,6,23,.06);
      padding: 1.5rem;
      backdrop-filter: saturate(1.1) blur(6px);
      transition: transform .2s ease, box-shadow .2s ease;
    }
    .card:hover{ transform: translateY(-2px); box-shadow: 0 16px 40px rgba(2,6,23,.08); }
    .btn{
      display:inline-flex; align-items:center; justify-content:center;
      border-radius: 12px; padding: .6rem 1rem; font-weight: 600;
      box-shadow: 0 2px 10px rgba(2,6,23,.06);
      transition: transform .12s ease, box-shadow .12s ease, background-color .12s ease;
      border: 1px solid transparent; text-decoration:none;
    }
    .btn:active{ transform: translateY(1px) scale(.99) }
    .btn-primary{ background: linear-gradient(90deg,var(--hrt-brand),var(--hrt-brand-2)); color:white; }
    .btn-primary:hover{ filter: brightness(1.05); box-shadow: 0 8px 24px rgba(79,70,229,.25); }
    .btn-light{ background:#f1f5f9; color:#0f172a; }
    .btn-light:hover{ background:#e2e8f0; }
    .badge{ font-size: .75rem; padding:.25rem .6rem; border-radius:999px; background:#eef2ff; color:#3730a3 }
    .link{ text-decoration: underline; text-underline-offset: 4px; }
    /* Inputs */
    input[type], textarea, select{
      border:1px solid #e2e8f0; border-radius:14px; padding:.6rem .8rem; outline: none;
      transition: box-shadow .12s ease, border-color .12s ease, background-color .12s ease;
      background:white;
    }
    input:focus, textarea:focus, select:focus{ border-color: var(--hrt-brand); box-shadow: 0 0 0 .25rem var(--hrt-ring); }
    /* Reveal on scroll */
    .reveal{ opacity: 0; transform: translateY(10px); }
    .reveal.show{ opacity: 1; transform: none; transition: opacity .45s ease, transform .45s ease; }
    @media (prefers-reduced-motion: reduce){
      .reveal{ opacity:1; transform:none }
    }
    /* Sticky header polish */
    .hr-nav{ position: sticky; top:0; z-index:50; backdrop-filter: blur(8px); background: rgba(255,255,255,.75); border-bottom:1px solid rgba(2,6,23,.06); }
    .hr-brand{ font-weight: 800; letter-spacing: .3px; background: linear-gradient(90deg,var(--hrt-brand),var(--hrt-brand-2)); -webkit-background-clip:text; background-clip:text; color: transparent; }
    .hr-container{ max-width: 1120px; margin: 0 auto; padding: .75rem 1rem; }
    /* Footer */
    .hr-footer a{ color: var(--hrt-muted); }
    .hr-footer a:hover{ color: var(--hrt-brand) }

    /* Skeleton overlay */
    .skeleton-overlay{ 
      position:absolute; inset:0; border-radius:inherit; 
      background: linear-gradient(90deg, rgba(0,0,0,0.05), rgba(255,255,255,0.35), rgba(0,0,0,0.05));
      background-size: 200% 100%;
      animation: shimmer 1.2s linear infinite;
      pointer-events: none;
    }
    @keyframes shimmer { 
      0%{ background-position-x: -200% } 
      100%{ background-position-x: 200% } 
    }
  
    /* Dark overrides for Tailwind grays and common backgrounds */
    html[data-theme="dark"] header { background: rgba(17,24,39,.86) !important; }
    html[data-theme="dark"] .bg-white, html[data-theme="dark"] .bg-white\/80, 
    html[data-theme="dark"] .card.bg-white, html[data-theme="dark"] .card { background: rgba(17,24,39,0.88) !important; }
    html[data-theme="dark"] body { background: radial-gradient(1000px 500px at 10% -10%, var(--hrt-bg2), transparent 60%), radial-gradient(1000px 500px at 110% 10%, #1f293733, transparent 60%), linear-gradient(180deg, var(--hrt-bg1), #0b1020); color: var(--hrt-text); }
    html[data-theme="dark"] .text-gray-700 { color: #e5e7eb !important; }
    html[data-theme="dark"] .text-gray-600 { color: #cbd5e1 !important; }
    html[data-theme="dark"] .text-gray-500 { color: #a1a1aa !important; }
    html[data-theme="dark"] .btn-light { background: #1f2937; color: #e5e7eb; border: 1px solid #374151; }
    html[data-theme="dark"] .btn-primary { box-shadow: 0 8px 24px rgba(99,102,241,.35); }
    html[data-theme="dark"] input, html[data-theme="dark"] textarea, html[data-theme="dark"] select{
      background: #0f172a; border-color: #334155; color: #e5e7eb;
    }
    html[data-theme="dark"] .skeleton-overlay{ background: linear-gradient(90deg, rgba(255,255,255,0.06), rgba(255,255,255,0.18), rgba(255,255,255,0.06)); }
  </style>
  <script>
    // Reveal animations
    (function(){
      const els = [].slice.call(document.querySelectorAll('.reveal'));
      if(!('IntersectionObserver' in window) || !els.length){ els.forEach(e=>e.classList.add('show')); return; }
      const io = new IntersectionObserver((entries)=>{
        entries.forEach(en=>{ if(en.isIntersecting){ en.target.classList.add('show'); io.unobserve(en.target); } });
      }, {threshold:.08});
      els.forEach(e=>io.observe(e));
    })();
    // Add a subtle scroll shadow to header
    (function(){
      const nav = document.querySelector('.hr-nav');
      if(!nav) return;
      const onScroll = ()=>{ nav.style.boxShadow = window.scrollY>4 ? '0 6px 20px rgba(2,6,23,.06)' : 'none'; };
      onScroll(); window.addEventListener('scroll', onScroll, {passive:true});
    })();
  </script>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      // Icons
      if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}

      // Dark mode
      const root = document.documentElement;
      const key = 'hrteam_theme';
      const btn = document.getElementById('themeToggle');
      const setTheme = (mode)=>{
        if(mode==='dark'){ root.setAttribute('data-theme','dark'); document.body.setAttribute('data-theme','dark'); btn && (btn.innerHTML='<i data-lucide="sun"></i>'); }
        else{ root.removeAttribute('data-theme'); document.body.removeAttribute('data-theme'); btn && (btn.innerHTML='<i data-lucide="moon"></i>'); }
        if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}
        localStorage.setItem(key, mode);
      };
      setTheme(localStorage.getItem(key) || 'light');
      if(btn){ btn.addEventListener('click', ()=>{
        const mode = root.getAttribute('data-theme')==='dark' ? 'light' : 'dark';
        setTheme(mode);
      });

      // Quick skeleton overlay on cards (brief, non-blocking)
      const cards = document.querySelectorAll('.card');
      cards.forEach(c=>{
        const overlay = document.createElement('div');
        overlay.className = 'skeleton-overlay';
        c.appendChild(overlay);
        setTimeout(()=>overlay.remove(), 320);
      });
      // Mobile nav toggle
      const navBtn = document.getElementById('navToggle');
      const nav = document.getElementById('mainNav');
      if(navBtn && nav){ navBtn.addEventListener('click', ()=>{ nav.classList.toggle('hidden'); }); }
    });
  </script>

</head>
<body class="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
  <header class="bg-white/80 backdrop-blur shadow-sm sticky top-0 z-30">
    <div class="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
      <a href="/" class="font-bold text-lg">HR Team <span class="text-indigo-600">Jobs</span></a>
      <button id="navToggle" class="md:hidden btn btn-light px-3" aria-label="Меню"><i data-lucide="menu"></i></button>
      <nav id="mainNav" class="hidden md:flex items-center gap-3 text-sm">
        <a class="hover:text-indigo-600" href="/faq">FAQ</a>
        <a class="hover:text-indigo-600" href="/p/rules">Правила</a>
        <a class="hover:text-indigo-600" href="/p/terms">Условия</a>
        <a class="hover:text-indigo-600" href="/p/privacy">Конфиденциальность</a>
        <button id="themeToggle" class="btn btn-light px-3" title="Тема"><i data-lucide="moon"></i></button>
        {% if user %}
          <a class="btn btn-light" href="/dashboard">Панель</a>
          <a class="btn btn-light" href="/dashboard#jobs">Заявки</a>
          <a class="btn btn-light" href="/dashboard#chats">Чаты</a>
          {% if user.role=='admin' %}<a class="btn btn-light" href="/admin">Админка</a>{% endif %}
          <a class="btn btn-light" href="/logout">Выход</a>
        {% else %}
          <a class="btn btn-light" href="/login">Вход</a>
          <a class="btn btn-primary" href="/register">Регистрация</a>
        {% endif %}
      </nav>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 py-8">
    {% block content %}{% endblock %}
  </main>

  <footer class="text-center text-sm text-gray-500 py-10">
    © {{ now.year }} HR Team.kz •
    <a class="link" href="/p/terms">Условия</a> •
    <a class="link" href="/p/privacy">Конфиденциальность</a> •
    <a class="link" href="/p/rules">Правила</a> •
    <a class="link" href="/faq">FAQ</a>
  </footer>

  <script>
    // IntersectionObserver for reveal
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{
        if(e.isIntersecting){ e.target.classList.add('show'); io.unobserve(e.target) }
      })
    }, {threshold:.12});
    document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
  </script>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      // Icons
      if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}

      // Dark mode
      const root = document.documentElement;
      const key = 'hrteam_theme';
      const btn = document.getElementById('themeToggle');
      const setTheme = (mode)=>{
        if(mode==='dark'){ root.setAttribute('data-theme','dark'); document.body.setAttribute('data-theme','dark'); btn && (btn.innerHTML='<i data-lucide="sun"></i>'); }
        else{ root.removeAttribute('data-theme'); document.body.removeAttribute('data-theme'); btn && (btn.innerHTML='<i data-lucide="moon"></i>'); }
        if (window.lucide && lucide.createIcons) try { lucide.createIcons(); } catch(e){}
        localStorage.setItem(key, mode);
      };
      setTheme(localStorage.getItem(key) || 'light');
      if(btn){ btn.addEventListener('click', ()=>{
        const mode = root.getAttribute('data-theme')==='dark' ? 'light' : 'dark';
        setTheme(mode);
      });

      // Quick skeleton overlay on cards (brief, non-blocking)
      const cards = document.querySelectorAll('.card');
      cards.forEach(c=>{
        const overlay = document.createElement('div');
        overlay.className = 'skeleton-overlay';
        c.appendChild(overlay);
        setTimeout(()=>overlay.remove(), 320);
      });
      // Mobile nav toggle
      const navBtn = document.getElementById('navToggle');
      const nav = document.getElementById('mainNav');
      if(navBtn && nav){ navBtn.addEventListener('click', ()=>{ nav.classList.toggle('hidden'); }); }
    });
  </script>
</body>
</html>
""",

    "landing.html": r"""
{% extends 'base.html' %}
{% block content %}
  <section class="reveal show animate-fadeUp">
    <div class="card bg-gradient-to-br from-white to-indigo-50">
      <div class="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 class="text-3xl md:text-4xl font-semibold mb-3">Маркетплейс заявок на подбор.</h1>
          <p class="text-gray-600 mb-6">Работодатели публикуют заявки с вознаграждением. Рекрутеры берут в работу, общаются в чате и закрывают позиции. Всё с модерацией и прозрачной историей событий.</p>
          <div class="flex gap-3">
            <a class="btn btn-primary" href="/register?role=employer">Я — Работодатель</a>
            <a class="btn btn-light" href="/register?role=recruiter">Я — Рекрутер</a>
          </div>
        </div>
        <div class="reveal">
          <div class="card">
            <div class="text-lg font-medium mb-2">Что внутри:</div>
            <ul class="text-gray-700 space-y-2 text-sm">
              <li>• Модерация заявок админом</li>
              <li>• До {{ max_recr }} рекрутеров на заявку</li>
              <li>• Чат с файлами (резюме, ТЗ)</li>
              <li>• Статусы: «приглашён → интервью → оффер → закрыто»</li>
              <li>• Инвойсы и события</li>
              <li>• Блокировка пользователей нарушителей</li>
              <li>• Страницы «Правила», «Условия», «Конфиденциальность», «FAQ»</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
{% endblock %}
"""
}