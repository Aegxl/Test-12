from typing import Dict
from jinja2 import Environment, DictLoader, select_autoescape

from .base import BASE_TEMPLATES
from .auth import AUTH_TEMPLATES
from .dashboard import DASHBOARD_TEMPLATES
from .job import JOB_TEMPLATES
from .chat import CHAT_TEMPLATES
from .admin import ADMIN_TEMPLATES
from .cms import CMS_TEMPLATES


def get_templates() -> Dict[str, str]:
    """Collect all templates into a single dictionary"""
    templates = {}
    templates.update(BASE_TEMPLATES)
    templates.update(AUTH_TEMPLATES)
    templates.update(DASHBOARD_TEMPLATES)
    templates.update(JOB_TEMPLATES)
    templates.update(CHAT_TEMPLATES)
    templates.update(ADMIN_TEMPLATES)
    templates.update(CMS_TEMPLATES)
    return templates


def get_jinja_env() -> Environment:
    """Create and configure Jinja2 environment"""
    templates = get_templates()
    return Environment(
        loader=DictLoader(templates),
        autoescape=select_autoescape(["html", "xml"])
    )