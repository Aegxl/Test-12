
from __future__ import annotations
import os
import json
import shutil
import uuid
import html as _pyhtml
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from fastapi import (
    FastAPI, Request, Form, Depends, HTTPException, status, WebSocket, WebSocketDisconnect,
    UploadFile, File, BackgroundTasks, Response
)
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

# Use a robust hash that doesn't require the external 'bcrypt' wheel to be present
from passlib.hash import pbkdf2_sha256 as hasher

from sqlalchemy import (
    create_engine, Column, Integer, String, DateTime, Text, ForeignKey, Float, UniqueConstraint, Boolean, and_, select
)
from sqlalchemy.orm import sessionmaker, declarative_base, relationship, Session

from jinja2 import Environment, DictLoader, select_autoescape
from itsdangerous import TimestampSigner, BadSignature

import smtplib
from email.mime.text import MIMEText
import requests

# ==========================================================================
#                        CONFIG & INITIALIZATION
# ==========================================================================
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
DB_URL = os.getenv("DB_URL", "sqlite:///market.db")
UPLOAD_DIR = os.path.abspath(os.getenv("UPLOAD_DIR", "../uploads"))
os.makedirs(UPLOAD_DIR, exist_ok=True)

SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT", "0") or 0)
SMTP_USER = os.getenv("SMTP_USER")
SMTP_PASS = os.getenv("SMTP_PASS")
EMAIL_FROM = os.getenv("EMAIL_FROM", "noreply@otvet.kz")
TG_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TG_CHAT = os.getenv("TELEGRAM_CHAT_ID")

MAX_RECRUITERS_PER_JOB = int(os.getenv("MAX_RECRUITERS_PER_JOB", "3"))

signer = TimestampSigner(SECRET_KEY)

engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ==========================================================================
#                                MODELS
# ==========================================================================
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(200), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False)  # employer|recruiter|admin
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    accepted_terms_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    jobs = relationship("Job", back_populates="employer", cascade="all, delete")

    def verify_password(self, password: str) -> bool:
        try:
            return hasher.verify(password, self.password_hash)
        except Exception:
            return False


class Job(Base):
    __tablename__ = "jobs"
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    reward = Column(Float, nullable=False)
    status = Column(String(20), default="pending")  # pending -> open -> closed
    city = Column(String(120), default="")
    is_remote = Column(Boolean, default=False)
    level = Column(String(20), default="")  # junior|middle|senior
    tags = Column(String(300), default="")  # comma-separated
    created_at = Column(DateTime, default=datetime.utcnow)

    employer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    employer = relationship("User", back_populates="jobs")

    assignments = relationship("JobRecruiter", back_populates="job", cascade="all, delete")


class JobRecruiter(Base):
    __tablename__ = "job_recruiters"
    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    recruiter_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    status = Column(String(20), default="active")  # active, dropped
    pipeline_status = Column(String(20), default="приглашён")  # приглашён, интервью, оффер, закрыто
    assigned_at = Column(DateTime, default=datetime.utcnow)

    job = relationship("Job", back_populates="assignments")
    recruiter = relationship("User")

    __table_args__ = (UniqueConstraint("job_id", "recruiter_id", name="uq_job_recruiter"),)


class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    recruiter_id = Column(Integer, ForeignKey("users.id"), nullable=False)  # чат уникален для пары (job, recruiter)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    recipient_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    attachment_id = Column(Integer, ForeignKey("attachments.id"), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Attachment(Base):
    __tablename__ = "attachments"
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    path = Column(String(500), nullable=False)
    uploader_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(Integer, primary_key=True)
    employer_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(10), default="KZT")
    description = Column(Text, default="")
    status = Column(String(20), default="draft")  # draft, sent, paid
    due_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    paid_at = Column(DateTime, nullable=True)


class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True)
    type = Column(String(50), nullable=False)  # job_created, job_opened, job_closed, assignment_taken, message, invoice_sent, invoice_paid, user_blocked, user_unblocked, recruiter_dropped
    actor_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=True)
    recruiter_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    invoice_id = Column(Integer, ForeignKey("invoices.id"), nullable=True)
    meta = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


# --- New simple CMS models ---
class Page(Base):
    __tablename__ = "pages"
    id = Column(Integer, primary_key=True)
    slug = Column(String(64), unique=True, nullable=False)   # "rules", "terms", "privacy", "about"
    title = Column(String(200), nullable=False)
    content = Column(Text, default="")
    is_public = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class FaqItem(Base):
    __tablename__ = "faq_items"
    id = Column(Integer, primary_key=True)
    question = Column(String(300), nullable=False)
    answer = Column(Text, nullable=False)
    rank = Column(Integer, default=0)
    is_public = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


Base.metadata.create_all(bind=engine)

# ==========================================================================
#                                TEMPLATES
# ==========================================================================
TEMPLATES: Dict[str, str] = {}
def tpl(name: str):
    def dec(fn):
        TEMPLATES[name] = fn()
        return fn
    return dec

env = Environment(loader=DictLoader(TEMPLATES), autoescape=select_autoescape(["html", "xml"]))

# ---------------- Base Layout ----------------
@tpl("base.html")
def _():
    return r"""
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{{ title or 'HR Team' }}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Subtle animations */
    @keyframes fadeUp { from {opacity:.0; transform: translateY(12px)} to {opacity:1; transform: translateY(0)} }
    .animate-fadeUp { animation: fadeUp .45s ease-out both }
    .card { @apply bg-white rounded-2xl shadow p-6 transition transform; }
    .card:hover { transform: translateY(-2px) scale(1.002); }
    .btn { @apply inline-flex items-center justify-center rounded-xl px-4 py-2 font-medium shadow transition; }
    .btn-primary { @apply bg-indigo-600 text-white hover:bg-indigo-700; }
    .btn-light { @apply bg-gray-100 hover:bg-gray-200; }
    .badge { @apply text-xs inline-block rounded-full px-3 py-1 bg-gray-100; }
    .link { @apply underline decoration-indigo-500 underline-offset-4 hover:text-indigo-600; }

    /* scroll reveal */
    .reveal { opacity: 0; transform: translateY(10px); }
    .reveal.show { opacity: 1; transform: none; transition: all .5s ease; }
  </style>
</head>
<body class="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
  <header class="bg-white/80 backdrop-blur shadow-sm sticky top-0 z-30">
    <div class="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
      <a href="/" class="font-bold text-lg">HR Team <span class="text-indigo-600">Jobs</span></a>
      <nav class="space-x-3 text-sm">
        <a class="hover:text-indigo-600" href="/faq">FAQ</a>
        <a class="hover:text-indigo-600" href="/page/rules">Правила</a>
        <a class="hover:text-indigo-600" href="/page/terms">Условия</a>
        <a class="hover:text-indigo-600" href="/page/privacy">Конфиденциальность</a>
        {% if user %}
          {% if user.role=='admin' %}<a class="btn btn-light" href="/admin">Админка</a>{% endif %}
          <a class="btn btn-light" href="/dashboard">Панель</a>
          <a class="btn btn-light" href="/logout">Выход</a>
        {% else %}
          <a class="btn btn-light" href="/login">Вход</a>
          <a class="btn btn-primary" href="/register">Регистрация</a>
        {% endif %}
      </nav>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 py-8">
    {% block content %}{% endblock %}
  </main>

  <footer class="text-center text-sm text-gray-500 py-10">
    © {{ now.year }} HR Team.kz •
    <a class="link" href="/page/terms">Условия</a> •
    <a class="link" href="/page/privacy">Конфиденциальность</a> •
    <a class="link" href="/page/rules">Правила</a> •
    <a class="link" href="/faq">FAQ</a>
  </footer>

  <script>
    // IntersectionObserver for reveal
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{
        if(e.isIntersecting){ e.target.classList.add('show'); io.unobserve(e.target) }
      })
    }, {threshold:.12});
    document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
  </script>
</body>
</html>
"""


@tpl("landing.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <section class="reveal show animate-fadeUp">
    <div class="card bg-gradient-to-br from-white to-indigo-50">
      <div class="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 class="text-3xl md:text-4xl font-semibold mb-3">Маркетплейс заявок на подбор.</h1>
          <p class="text-gray-600 mb-6">Работодатели публикуют заявки с вознаграждением. Рекрутеры берут в работу, общаются в чате и закрывают позиции. Всё с модерацией и прозрачной историей событий.</p>
          <div class="flex gap-3">
            <a class="btn btn-primary" href="/register?role=employer">Я — Работодатель</a>
            <a class="btn btn-light" href="/register?role=recruiter">Я — Рекрутер</a>
          </div>
        </div>
        <div class="reveal">
          <div class="card">
            <div class="text-lg font-medium mb-2">Что внутри:</div>
            <ul class="text-gray-700 space-y-2 text-sm">
              <li>• Модерация заявок админом</li>
              <li>• До {{ max_recr }} рекрутеров на заявку</li>
              <li>• Чат с файлами (резюме, ТЗ)</li>
              <li>• Статусы: «приглашён → интервью → оффер → закрыто»</li>
              <li>• Инвойсы и события</li>
              <li>• Блокировка пользователей нарушителей</li>
              <li>• Страницы «Правила», «Условия», «Конфиденциальность», «FAQ»</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
{% endblock %}
"""


@tpl("auth_login.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-md mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">Вход</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Email
        <input class="w-full border rounded-xl p-2" type="email" name="email" required />
      </label>
      <label class="block mb-4">Пароль
        <input class="w-full border rounded-xl p-2" type="password" name="password" required />
      </label>
      <button class="btn btn-primary w-full" type="submit">Войти</button>
    </form>
  </div>
{% endblock %}
"""


@tpl("auth_register.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-md mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">Регистрация</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Имя
        <input class="w-full border rounded-xl p-2" type="text" name="name" required />
      </label>
      <label class="block mb-2">Email
        <input class="w-full border rounded-xl p-2" type="email" name="email" required />
      </label>
      <label class="block mb-2">Пароль
        <input class="w-full border rounded-xl p-2" type="password" name="password" required />
      </label>
      <label class="block mb-2">Роль
        <select class="w-full border rounded-xl p-2" name="role" required>
          <option value="employer" {% if pref_role=='employer' %}selected{% endif %}>Работодатель</option>
          <option value="recruiter" {% if pref_role=='recruiter' %}selected{% endif %}>Рекрутер</option>
        </select>
      </label>

      <label class="block mb-4">
        <input type="checkbox" name="accept_terms" value="1" required />
        Я принимаю <a href="/page/terms" class="link">Условия</a> и <a href="/page/privacy" class="link">Политику конфиденциальности</a>
      </label>

      <button class="btn btn-primary w-full" type="submit">Создать аккаунт</button>
    </form>
  </div>
{% endblock %}
"""


@tpl("dashboard_employer.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-semibold">Мои заявки</h1>
    <a class="btn btn-primary" href="/jobs/new">+ Новая заявка</a>
  </div>
  <div class="grid gap-4">
    {% for job in jobs %}
      <div class="card reveal">
        <div class="flex items-center justify-between">
          <div>
            <div class="text-lg font-semibold">{{ job.title }}</div>
            <div class="text-gray-600">Вознаграждение: <strong>{{ job.reward_fmt }}</strong></div>
            <div class="text-gray-500 text-sm">Статус: {{ job.status|capitalize }} • {{ job.city or '—' }} {{ job.is_remote and '(дистанционная работа)' or '' }} • {{ job.level or '—' }}</div>
            {% if job.tags %}<div class="text-xs text-gray-500">Теги: {{ job.tags }}</div>{% endif %}
            <div class="text-gray-500 text-sm">Создана: {{ job.created_at.strftime('%d.%m.%Y %H:%M') }}</div>
          </div>
          <div class="space-x-2">
            <a class="btn btn-light" href="/jobs/{{ job.id }}">Подробнее</a>
          </div>
        </div>
      </div>
    {% else %}
      <div class="text-gray-500">Пока нет заявок.</div>
    {% endfor %}
  </div>

  <div class="mt-8">
    <h2 class="text-xl font-semibold mb-2">События</h2>
    <div class="space-y-2">
      {% for e in events %}
        <div class="text-sm text-gray-600">• {{ e.created_at.strftime('%d.%m %H:%M') }} — {{ e.text }}</div>
      {% else %}
        <div class="text-gray-400 text-sm">Пока пусто.</div>
      {% endfor %}
    </div>
  </div>
{% endblock %}
"""


@tpl("dashboard_recruiter.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <form class="card mb-6 grid md:grid-cols-5 gap-3" method="get">
    <div>
      <label class="text-xs text-gray-500">Город</label>
      <input class="w-full border rounded-xl p-2" type="text" name="city" value="{{ filters.city }}" />
    </div>
    <div>
      <label class="text-xs text-gray-500">Уровень</label>
      <select class="w-full border rounded-xl p-2" name="level">
        <option value="">Любой</option>
        {% for lv in ['junior','middle','senior'] %}
          <option value="{{ lv }}" {% if filters.level==lv %}selected{% endif %}>{{ lv }}</option>
        {% endfor %}
      </select>
    </div>
    <div class="flex items-end">
      <label class="inline-flex items-center gap-2">
        <input type="checkbox" name="remote" value="1" {% if filters.remote %}checked{% endif %} /> дистанционная работа
      </label>
    </div>
    <div class="md:col-span-2">
      <label class="text-xs text-gray-500">Теги (через запятую)</label>
      <input class="w-full border rounded-xl p-2" type="text" name="tags" value="{{ filters.tags }}" />
    </div>
    <div class="md:col-span-5 flex justify-end">
      <button class="btn btn-light" type="submit">Фильтровать</button>
    </div>
  </form>

  <div class="grid md:grid-cols-2 gap-6">
    <div>
      <h2 class="text-xl font-semibold mb-2">Доступные заявки</h2>
      <div class="space-y-4">
        {% for job in open_jobs %}
          <div class="card reveal">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-lg font-semibold">{{ job.title }}</div>
                <div class="text-gray-600">{{ job.city or '—' }} {{ job.is_remote and '(дистанционная работа)' or '' }} • {{ job.level or '—' }}</div>
                {% if job.tags %}<div class="text-xs text-gray-500">Теги: {{ job.tags }}</div>{% endif %}
                <div class="text-gray-600">Вознаграждение: <strong>{{ job.reward_fmt }}</strong></div>
                <div class="text-gray-500 text-sm">Свободно мест: {{ job.free_slots }} из {{ max_recr }}</div>
              </div>
              <form method="post" action="/jobs/{{ job.id }}/take">
                <button class="btn btn-primary" {% if job.free_slots==0 %}disabled{% endif %}>Взяться</button>
              </form>
            </div>
          </div>
        {% else %}
          <div class="text-gray-500">Нет подходящих заявок.</div>
        {% endfor %}
      </div>
    </div>
    <div>
      <h2 class="text-xl font-semibold mb-2">Мои вакансии</h2>
      <div class="space-y-4">
        {% for a in my_assignments %}
          <div class="card reveal">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-lg font-semibold">{{ a.job.title }}</div>
                <div class="text-gray-600">Работодатель: {{ a.job.employer.name }}</div>
                <div class="text-gray-500 text-sm">Статус подбора: {{ a.pipeline_status }}</div>
                <div class="text-gray-500 text-sm">Назначен: {{ a.assigned_at.strftime('%d.%m.%Y %H:%M') }}</div>
              </div>
              <div class="space-x-2">
                <a class="btn btn-light" href="/chat/{{ a.job.id }}/{{ user.id }}">Чат</a>
                <form method="post" action="/assign/{{ a.id }}/stage" class="inline">
                  <select class="border rounded-xl p-1" name="stage" onchange="this.form.submit()">
                    {% for st in ['приглашён','интервью','оффер','закрыто'] %}
                      <option value="{{ st }}" {% if a.pipeline_status==st %}selected{% endif %}>{{ st }}</option>
                    {% endfor %}
                  </select>
                </form>
              </div>
            </div>
          </div>
        {% else %}
          <div class="text-gray-500">Вы ещё не взялись ни за одну заявку.</div>
        {% endfor %}
      </div>
    </div>
  </div>

  <div class="mt-8">
    <h2 class="text-xl font-semibold mb-2">События</h2>
    <div class="space-y-2">
      {% for e in events %}
        <div class="text-sm text-gray-600">• {{ e.created_at.strftime('%d.%m %H:%M') }} — {{ e.text }}</div>
      {% else %}
        <div class="text-gray-400 text-sm">Пока пусто.</div>
      {% endfor %}
    </div>
  </div>
{% endblock %}
"""


@tpl("job_new.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-2xl mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">Новая заявка</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Название позиции
        <input class="w-full border rounded-xl p-2" type="text" name="title" required />
      </label>
      <label class="block mb-2">Описание (кратко)
        <textarea class="w-full border rounded-xl p-2" name="description" rows="4" required></textarea>
      </label>
      <div class="grid md:grid-cols-3 gap-4">
        <label class="block mb-2">Город
          <input class="w-full border rounded-xl p-2" type="text" name="city" />
        </label>
        <label class="block mb-2">Уровень
          <select class="w-full border rounded-xl p-2" name="level">
            <option value="">—</option>
            <option value="junior">junior</option>
            <option value="middle">middle</option>
            <option value="senior">senior</option>
          </select>
        </label>
        <label class="block mb-2">дистанционная работа
          <select class="w-full border rounded-xl p-2" name="is_remote">
            <option value="0">Нет</option>
            <option value="1">Да</option>
          </select>
        </label>
      </div>
      <label class="block mb-2">Теги (через запятую)
        <input class="w-full border rounded-xl p-2" type="text" name="tags" placeholder="бухгалтерия, 1С, FMCG" />
      </label>
      <label class="block mb-4">Вознаграждение за закрытие (₸)
        <input class="w-full border rounded-xl p-2" type="number" step="1" min="0" name="reward" required />
      </label>
      <p class="text-sm text-gray-500 mb-3">После создания заявка будет иметь статус <strong>pending</strong> и появится в ленте после модерации админом.</p>
      <button class="btn btn-primary" type="submit">Создать</button>
    </form>
  </div>
{% endblock %}
"""


@tpl("job_detail.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto space-y-6">
    <div class="card animate-fadeUp">
      <div class="flex items-start justify-between">
        <div>
          <h1 class="text-2xl font-semibold">{{ job.title }}</h1>
          <div class="text-gray-600">Вознаграждение: <strong>{{ job.reward_fmt }}</strong></div>
          <div class="text-gray-500 text-sm">Статус: {{ job.status }} | Создана: {{ job.created_at.strftime('%d.%m.%Y %H:%M') }}</div>
          <div class="text-gray-500 text-sm">{{ job.city or '—' }} {{ job.is_remote and '(дистанционная работа)' or '' }} • {{ job.level or '—' }}</div>
          {% if job.tags %}<div class="text-gray-500 text-sm">Теги: {{ job.tags }}</div>{% endif %}
        </div>
        <div class="space-x-2">
          {% if can_toggle %}
          <form method="post" action="/jobs/{{ job.id }}/toggle" class="inline">
            <button class="btn btn-light">{{ 'Открыть' if job.status!='open' else 'Закрыть' }}</button>
          </form>
          {% endif %}
        </div>
      </div>
      <p class="mt-4 whitespace-pre-line">{{ job.description }}</p>
    </div>

    <div class="card">
      <h2 class="text-xl font-semibold mb-4">Рекрутеры ({{ assignments|length }}/{{ max_recr }})</h2>
      <div class="space-y-3">
        {% for a in assignments %}
          <div class="flex items-center justify-between border-b pb-3">
            <div>
              <div class="font-medium">{{ a.recruiter.name }}</div>
              <div class="text-gray-500 text-sm">Email: {{ a.recruiter.email }}</div>
              <div class="text-gray-500 text-sm">Статус подбора: {{ a.pipeline_status }}</div>
            </div>
            <div class="space-x-2">
              <a class="btn btn-light" href="/chat/{{ job.id }}/{{ a.recruiter.id }}">Открыть чат</a>
              {% if is_admin %}
                <form method="post" action="/admin/assign/{{ a.id }}/drop" class="inline">
                  <button class="btn btn-light">Удалить из заявки</button>
                </form>
              {% endif %}
            </div>
          </div>
        {% else %}
          <div class="text-gray-500">Пока никто не взялся.</div>
        {% endfor %}
      </div>
    </div>
  </div>
{% endblock %}
"""


@tpl("chat.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto card animate-fadeUp">
    <div class="flex items-center justify-between mb-4">
      <div>
        <div class="text-sm text-gray-500">Вакансия</div>
        <h1 class="text-xl font-semibold">{{ job.title }}</h1>
        <div class="text-gray-500 text-sm">Собеседники: {{ employer.name }} ↔ {{ recruiter.name }}</div>
      </div>
      <a class="btn btn-light" href="/dashboard">Назад</a>
    </div>

    <div id="messages" class="border rounded-xl p-3 h-80 overflow-y-auto bg-gray-50"></div>

    <form id="chat-form" class="mt-4 flex gap-2">
      <input id="msg" type="text" class="flex-1 border rounded-xl p-2" placeholder="Сообщение..." required />
      <label class="btn btn-light cursor-pointer">
        📎
        <input id="file" type="file" class="hidden" />
      </label>
      <button class="btn btn-primary" type="submit">Отправить</button>
    </form>
  </div>

  <script>
    const wsToken = "{{ ws_token }}";
    const wsUrl = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws?token=${encodeURIComponent(wsToken)}`;
    const socket = new WebSocket(wsUrl);

    socket.onmessage = (event) => {
      const data = event.data;
      const box = document.getElementById('messages');
      const div = document.createElement('div');
      div.className = 'mb-2';
      div.innerHTML = data;
      box.appendChild(div);
      box.scrollTop = box.scrollHeight;
    };

    function escapeHtml(str){
      return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    document.getElementById('chat-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = document.getElementById('msg');
      const fileInput = document.getElementById('file');
      const msg = input.value.trim();
      if(fileInput.files.length > 0){
        const f = fileInput.files[0];
        const fd = new FormData();
        fd.append('file', f);
        const res = await fetch(`/api/chat/{{ job.id }}/{{ recruiter.id }}/upload`, {method:'POST', body: fd});
        const data = await res.json();
        if(data.ok){
          socket.send(JSON.stringify({type:'message', content: data.placeholder}));
          fileInput.value = '';
        }
        return;
      }
      if(!msg) return;
      socket.send(JSON.stringify({type:'message', content: msg}));
      input.value = '';
    });

    (async function init(){
      const res = await fetch(`/api/chat/{{ job.id }}/{{ recruiter.id }}/list`);
      const html = await res.text();
      const box = document.getElementById('messages');
      box.innerHTML = html;
      box.scrollTop = box.scrollHeight;
    })();
  </script>
{% endblock %}
"""


@tpl("admin.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <h1 class="text-2xl font-semibold mb-4">Админ-панель</h1>
  <div class="grid md:grid-cols-2 gap-6">
    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Ожидают модерации</h2>
      {% for j in pending_jobs %}
        <div class="flex items-center justify-between border-b py-2">
          <div>
            <div class="font-medium">{{ j.title }}</div>
            <div class="text-sm text-gray-500">{{ j.city or '—' }} {{ j.is_remote and '(дистанционная работа)' or '' }} • {{ j.level or '—' }} • {{ j.reward_fmt }}</div>
          </div>
          <div class="space-x-2">
            <form method="post" action="/admin/job/{{ j.id }}/approve" class="inline"><button class="btn btn-primary">Одобрить</button></form>
            <form method="post" action="/admin/job/{{ j.id }}/reject" class="inline"><button class="btn btn-light">Отклонить</button></form>
          </div>
        </div>
      {% else %}
        <div class="text-sm text-gray-500">Нет новых заявок.</div>
      {% endfor %}
    </div>

    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Пользователи</h2>
      {% for u in users %}
        <div class="flex items-center justify-between border-b py-2">
          <div>
            <div class="font-medium">{{ u.name }}</div>
            <div class="text-sm text-gray-500">{{ u.email }} • {{ u.role }} • {{ u.is_active and 'активен' or 'заблокирован' }}</div>
          </div>
          <div class="space-x-2">
            {% if u.is_active %}
              <form method="post" action="/admin/user/{{ u.id }}/block" class="inline"><button class="btn btn-light">Заблокировать</button></form>
            {% else %}
              <form method="post" action="/admin/user/{{ u.id }}/unblock" class="inline"><button class="btn btn-primary">Разблокировать</button></form>
            {% endif %}
          </div>
        </div>
      {% endfor %}
    </div>
  </div>

  <div class="grid md:grid-cols-2 gap-6 mt-6">
    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Инвойсы</h2>
      <form method="post" action="/admin/invoices/new" class="grid md:grid-cols-4 gap-3 mb-4">
        <select class="border rounded-xl p-2" name="employer_id" required>
          <option value="">Работодатель…</option>
          {% for e in employers %}
            <option value="{{ e.id }}">{{ e.name }} ({{ e.email }})</option>
          {% endfor %}
        </select>
        <input class="border rounded-xl p-2" type="number" step="1" min="0" name="amount" placeholder="Сумма, ₸" required />
        <input class="border rounded-xl p-2" type="text" name="description" placeholder="Описание" />
        <button class="btn btn-primary" type="submit">Выставить</button>
      </form>
      <div class="space-y-2">
        {% for inv in invoices %}
          <div class="flex items-center justify-between border-b py-2">
            <div>
              <div class="font-medium">#{{ inv.id }} — {{ inv.amount|int }} {{ inv.currency }} ({{ inv.status }})</div>
              <div class="text-sm text-gray-500">{{ inv.employer.name }} • {{ inv.description or '—' }}</div>
            </div>
            <div class="space-x-2">
              {% if inv.status!='paid' %}
                <form method="post" action="/admin/invoices/{{ inv.id }}/mark-paid" class="inline"><button class="btn btn-light">Отметить как оплаченный</button></form>
              {% endif %}
            </div>
          </div>
        {% else %}
          <div class="text-sm text-gray-500">Пока нет инвойсов.</div>
        {% endfor %}
      </div>
    </div>

    <div class="card">
      <h2 class="text-xl font-semibold mb-3">Страницы (CMS)</h2>
      <div class="mb-3">
        <a class="btn btn-primary" href="/admin/pages/new">+ Новая страница</a>
        <a class="btn btn-light" href="/admin/faq">FAQ</a>
      </div>
      {% for p in pages %}
        <div class="flex items-center justify-between border-b py-2">
          <div>
            <div class="font-medium">{{ p.title }}</div>
            <div class="text-sm text-gray-500">/{{ p.slug }} • {{ p.is_public and 'публична' or 'скрыта' }} • обновлено {{ p.updated_at.strftime('%d.%m %H:%M') }}</div>
          </div>
          <div class="space-x-2">
            <a class="btn btn-light" href="/page/{{ p.slug }}" target="_blank">Открыть</a>
            <a class="btn btn-light" href="/admin/pages/{{ p.id }}/edit">Править</a>
          </div>
        </div>
      {% else %}
        <div class="text-sm text-gray-500">Пока нет страниц.</div>
      {% endfor %}
    </div>
  </div>
{% endblock %}
"""


@tpl("page_view.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <article class="max-w-3xl mx-auto card animate-fadeUp">
    <h1 class="text-2xl font-semibold mb-2">{{ page.title }}</h1>
    <div class="prose prose-sm max-w-none whitespace-pre-line">{{ page.content }}</div>
  </article>
{% endblock %}
"""


@tpl("pages_admin_list.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-semibold">Страницы</h1>
    <a class="btn btn-primary" href="/admin/pages/new">+ Новая страница</a>
  </div>
  <div class="card">
    {% for p in pages %}
      <div class="flex items-center justify-between border-b py-2">
        <div>
          <div class="font-medium">{{ p.title }}</div>
          <div class="text-sm text-gray-500">/{{ p.slug }} • {{ p.is_public and 'публична' or 'скрыта' }}</div>
        </div>
        <div class="space-x-2">
          <a class="btn btn-light" href="/page/{{ p.slug }}" target="_blank">Открыть</a>
          <a class="btn btn-light" href="/admin/pages/{{ p.id }}/edit">Править</a>
        </div>
      </div>
    {% else %}
      <div class="text-sm text-gray-500">Пока нет страниц.</div>
    {% endfor %}
  </div>
{% endblock %}
"""


@tpl("page_edit.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">{{ page and 'Правка страницы' or 'Новая страница' }}</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Slug (латиница, напр. rules/terms/privacy/about)
        <input class="w-full border rounded-xl p-2" type="text" name="slug" value="{{ page and page.slug or '' }}" required />
      </label>
      <label class="block mb-2">Заголовок
        <input class="w-full border rounded-xl p-2" type="text" name="title" value="{{ page and page.title or '' }}" required />
      </label>
      <label class="block mb-4">Содержимое (ваш текст)
        <textarea class="w-full border rounded-xl p-2" name="content" rows="12">{{ page and page.content or '' }}</textarea>
      </label>
      <div class="flex items-center gap-4">
        <label><input type="checkbox" name="is_public" value="1" {% if not page or page.is_public %}checked{% endif %}/> Публичная</label>
        <button class="btn btn-primary" type="submit">Сохранить</button>
        {% if page %}
          <form method="post" action="/admin/pages/{{ page.id }}/delete" onsubmit="return confirm('Удалить страницу?')" class="inline">
            <button class="btn btn-light" type="submit">Удалить</button>
          </form>
        {% endif %}
      </div>
    </form>
  </div>
{% endblock %}
"""


@tpl("faq_public.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto space-y-4">
    <h1 class="text-2xl font-semibold">FAQ — Частые вопросы</h1>
    {% for f in items %}
      <div class="card reveal">
        <div class="font-semibold mb-2">{{ loop.index }}. {{ f.question }}</div>
        <div class="text-gray-700 whitespace-pre-line">{{ f.answer }}</div>
      </div>
    {% else %}
      <div class="text-gray-500">Пока нет вопросов.</div>
    {% endfor %}
  </div>
{% endblock %}
"""


@tpl("faq_admin.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-semibold">FAQ</h1>
    <a class="btn btn-primary" href="/admin/faq/new">+ Новый вопрос</a>
  </div>
  <div class="space-y-3">
    {% for f in items %}
      <div class="card">
        <div class="flex items-start justify-between gap-4">
          <div>
            <div class="text-sm text-gray-500">#{{ f.id }} • {{ f.is_public and 'опубликован' or 'скрыт' }} • порядок {{ f.rank }}</div>
            <div class="font-semibold mb-2">{{ f.question }}</div>
            <div class="text-gray-700 whitespace-pre-line">{{ f.answer }}</div>
          </div>
          <div class="space-x-2">
            <a class="btn btn-light" href="/admin/faq/{{ f.id }}/edit">Править</a>
            <form method="post" action="/admin/faq/{{ f.id }}/delete" onsubmit="return confirm('Удалить?')" class="inline"><button class="btn btn-light">Удалить</button></form>
          </div>
        </div>
      </div>
    {% else %}
      <div class="text-gray-500">Пока пусто.</div>
    {% endfor %}
  </div>
{% endblock %}
"""


@tpl("faq_edit.html")
def _():
    return r"""
{% extends 'base.html' %}
{% block content %}
  <div class="max-w-3xl mx-auto card animate-fadeUp">
    <h1 class="text-xl font-semibold mb-4">{{ item and 'Правка вопроса' or 'Новый вопрос' }}</h1>
    {% if error %}<div class="mb-4 text-red-600">{{ error }}</div>{% endif %}
    <form method="post">
      <label class="block mb-2">Вопрос
        <input class="w-full border rounded-xl p-2" type="text" name="question" value="{{ item and item.question or '' }}" required />
      </label>
      <label class="block mb-4">Ответ
        <textarea class="w-full border rounded-xl p-2" name="answer" rows="10" required>{{ item and item.answer or '' }}</textarea>
      </label>
      <div class="grid md:grid-cols-3 gap-4 mb-4">
        <label>Порядок <input class="w-full border rounded-xl p-2" type="number" name="rank" value="{{ item and item.rank or 0 }}" /></label>
        <label class="flex items-center gap-2"><input type="checkbox" name="is_public" value="1" {% if not item or item.is_public %}checked{% endif %}/> Опубликовать</label>
      </div>
      <button class="btn btn-primary" type="submit">Сохранить</button>
    </form>
  </div>
{% endblock %}
"""

# ==========================================================================
#                               UTILITIES
# ==========================================================================
def escape_html(s: str) -> str:
    return _pyhtml.escape(s, quote=False)

def fmt_money(value: float) -> str:
    try:
        return f"{value:,.0f} ₸".replace(",", " ")
    except Exception:
        return f"{value} ₸"

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def current_user(request: Request, db: Session) -> Optional[User]:
    uid = request.session.get("user_id")
    if not uid:
        return None
    u = db.get(User, uid)
    if u and not u.is_active:
        return None
    return u

def login_required(role: Optional[str] = None):
    def dep(request: Request, db: Session = Depends(get_db)) -> User:
        user = current_user(request, db)
        if not user:
            raise HTTPException(status_code=302, detail="Redirect to login", headers={"Location": "/login"})
        if role and user.role != role:
            raise HTTPException(status_code=403, detail="Forbidden")
        return user
    return dep

def record_event(db: Session, type_: str, **meta):
    e = Event(type=type_, actor_id=meta.get("actor_id"), job_id=meta.get("job_id"),
              recruiter_id=meta.get("recruiter_id"), invoice_id=meta.get("invoice_id"),
              meta=json.dumps(meta, ensure_ascii=False))
    db.add(e)
    db.commit()

def send_email_safe(to_email: str, subject: str, text: str):
    if not (SMTP_HOST and SMTP_PORT and EMAIL_FROM):
        return
    try:
        msg = MIMEText(text, _charset="utf-8")
        msg["Subject"] = subject
        msg["From"] = EMAIL_FROM
        msg["To"] = to_email
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as s:
            if SMTP_USER and SMTP_PASS:
                try:
                    s.starttls()
                except Exception:
                    pass
                s.login(SMTP_USER, SMTP_PASS)
            s.sendmail(EMAIL_FROM, [to_email], msg.as_string())
    except Exception:
        pass

def send_telegram_safe(text: str):
    if not (TG_TOKEN and TG_CHAT):
        return
    try:
        requests.post(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage", json={"chat_id": TG_CHAT, "text": text})
    except Exception:
        pass

def make_ws_token(uid: int, job_id: int, recruiter_id: int) -> str:
    payload = f"{uid}:{job_id}:{recruiter_id}"
    return signer.sign(payload.encode()).decode()

def verify_ws_token(token: str) -> Tuple[int,int,int]:
    try:
        data = signer.unsign(token.encode(), max_age=60*60*24).decode()
        parts = data.split(":")
        if len(parts) != 3:
            raise BadSignature("bad parts")
        uid, job_id, recruiter_id = map(int, parts)
        return uid, job_id, recruiter_id
    except BadSignature:
        raise HTTPException(status_code=401, detail="bad token")

# ==========================================================================
#                          APP & STATIC MOUNT
# ==========================================================================
app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY, session_cookie="otvet_session", same_site="lax")
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# Helper: render
def render(name: str, request: Request, **context) -> HTMLResponse:
    with SessionLocal() as db:
        user = current_user(request, db)
    now = datetime.utcnow()
    html = env.get_template(name).render({"request": request, "user": user, "now": now, "max_recr": MAX_RECRUITERS_PER_JOB, **context})
    return HTMLResponse(html)

# ==========================================================================
#                               ROUTES
# ==========================================================================
@app.get("/", response_class=HTMLResponse)
async def landing(request: Request):
    return render("landing.html", request, title="HR Team")

# ---------------- Auth ----------------
@app.get("/register", response_class=HTMLResponse)
async def register_form(request: Request, role: Optional[str] = None):
    return render("auth_register.html", request, pref_role=role or "employer")

@app.post("/register")
async def register(request: Request,
                   name: str = Form(...),
                   email: str = Form(...),
                   password: str = Form(...),
                   role: str = Form(...),
                   accept_terms: Optional[str] = Form(None),
                   db: Session = Depends(get_db)):
    role = role.strip().lower()
    if role not in {"employer", "recruiter", "admin"}:
        return render("auth_register.html", request, error="Неверная роль", pref_role=role)
    if db.execute(select(User).where(User.email == email.strip().lower())).scalar_one_or_none():
        return render("auth_register.html", request, error="Email уже зарегистрирован", pref_role=role)
    if accept_terms != "1":
        return render("auth_register.html", request, error="Нужно принять условия использования", pref_role=role)
    user = User(
        name=name.strip(),
        email=email.strip().lower(),
        password_hash=hasher.hash(password),
        role=role,
        accepted_terms_at=datetime.utcnow(),
        is_active=True
    )
    db.add(user)
    db.commit()
    request.session["user_id"] = user.id
    request.session["role"] = user.role
    return RedirectResponse("/dashboard", status_code=302)

@app.get("/login", response_class=HTMLResponse)
async def login_form(request: Request):
    return render("auth_login.html", request)

@app.post("/login")
async def login(request: Request, email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == email.strip().lower())).scalar_one_or_none()
    if not user or not user.verify_password(password) or not user.is_active:
        return render("auth_login.html", request, error="Неверные данные или пользователь заблокирован")
    request.session["user_id"] = user.id
    request.session["role"] = user.role
    return RedirectResponse("/dashboard", status_code=302)

@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=302)

# ---------------- Dashboards ----------------
@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=302)

    def fmt_event(e: Event):
        try:
            meta = json.loads(e.meta) if e.meta else {}
        except Exception:
            meta = {}
        mapping = {
            'job_created': f"Создана заявка #{meta.get('job_id')}",
            'job_opened': f"Открыта заявка #{meta.get('job_id')}",
            'job_closed': f"Закрыта заявка #{meta.get('job_id')}",
            'assignment_taken': f"Рекрутер взялся за заявку #{meta.get('job_id')}",
            'message': f"Новое сообщение по заявке #{meta.get('job_id')}",
            'invoice_sent': f"Выставлен инвойс #{meta.get('invoice_id')}",
            'invoice_paid': f"Оплачен инвойс #{meta.get('invoice_id')}",
            'user_blocked': f"Пользователь заблокирован",
            'user_unblocked': f"Пользователь разблокирован",
            'recruiter_dropped': f"Рекрутер удалён из заявки #{meta.get('job_id')}",
        }
        return type("EObj", (), {"created_at": e.created_at, "text": mapping.get(e.type, e.type)})

    if user.role == "employer":
        jobs = db.query(Job).filter(Job.employer_id == user.id).order_by(Job.created_at.desc()).all()
        for j in jobs:
            j.reward_fmt = fmt_money(j.reward)
        ev = db.query(Event).filter(Event.job_id.in_([j.id for j in jobs]) if jobs else Event.id==Event.id).order_by(Event.created_at.desc()).limit(20).all()
        events = [fmt_event(e) for e in ev]
        return render("dashboard_employer.html", request, jobs=jobs, events=events)

    elif user.role == "recruiter":
        city = (request.query_params.get('city') or '').strip()
        level = (request.query_params.get('level') or '').strip()
        remote = request.query_params.get('remote') == '1'
        tags = (request.query_params.get('tags') or '').strip()

        q = db.query(Job).filter(Job.status == "open")
        if city:
            q = q.filter(Job.city.ilike(f"%{city}%"))
        if level:
            q = q.filter(Job.level == level)
        if remote:
            q = q.filter(Job.is_remote == True)
        if tags:
            for t in [t.strip() for t in tags.split(',') if t.strip()]:
                q = q.filter(Job.tags.ilike(f"%{t}%"))

        open_jobs = []
        for j in q.order_by(Job.created_at.desc()).all():
            active_count = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==j.id, JobRecruiter.status=="active")).count()
            already = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==j.id, JobRecruiter.recruiter_id==user.id, JobRecruiter.status=="active")).first()
            if active_count < MAX_RECRUITERS_PER_JOB and not already and j.employer_id != user.id:
                j.reward_fmt = fmt_money(j.reward)
                j.free_slots = MAX_RECRUITERS_PER_JOB - active_count
                open_jobs.append(j)
        my_assignments = db.query(JobRecruiter).filter(and_(JobRecruiter.recruiter_id==user.id, JobRecruiter.status=="active")).order_by(JobRecruiter.assigned_at.desc()).all()
        ev = db.query(Event).order_by(Event.created_at.desc()).limit(20).all()
        events = [fmt_event(e) for e in ev]
        return render("dashboard_recruiter.html", request, open_jobs=open_jobs, my_assignments=my_assignments, max_recr=MAX_RECRUITERS_PER_JOB, filters={"city":city,"level":level,"remote":remote,"tags":tags}, events=events)

    else:
        return RedirectResponse("/admin", status_code=302)

# ---------------- Employer: create job ----------------
@app.get("/jobs/new", response_class=HTMLResponse)
async def job_new_form(request: Request, user: User = Depends(login_required("employer"))):
    return render("job_new.html", request)

@app.post("/jobs/new")
async def job_new(request: Request,
                  title: str = Form(...), description: str = Form(...), reward: float = Form(...),
                  city: str = Form(""), level: str = Form(""), is_remote: str = Form("0"), tags: str = Form(""),
                  db: Session = Depends(get_db), user: User = Depends(login_required("employer"))):
    title = title.strip()
    description = description.strip()
    try:
        reward_val = float(reward)
    except Exception:
        return render("job_new.html", request, error="Некорректная сумма")
    job = Job(title=title, description=description, reward=reward_val, employer_id=user.id,
              city=city.strip(), level=(level or '').strip(), is_remote=(is_remote == '1'),
              tags=(tags or '').strip(), status='pending')
    db.add(job)
    db.commit()
    record_event(db, 'job_created', actor_id=user.id, job_id=job.id)
    return RedirectResponse(f"/jobs/{job.id}", status_code=302)

# Employer/Admin: job detail
@app.get("/jobs/{job_id}", response_class=HTMLResponse)
async def job_detail(request: Request, job_id: int, db: Session = Depends(get_db), user: User = Depends(login_required())):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    if user.role != 'admin' and job.employer_id != user.id:
        raise HTTPException(status_code=403, detail="Forbidden")
    job.reward_fmt = fmt_money(job.reward)
    assignments = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==job.id, JobRecruiter.status=="active")).all()
    can_toggle = (user.role in {'admin'} or user.id == job.employer_id)
    return render("job_detail.html", request, job=job, assignments=assignments, max_recr=MAX_RECRUITERS_PER_JOB, can_toggle=can_toggle, is_admin=(user.role=='admin'))

@app.post("/jobs/{job_id}/toggle")
async def job_toggle(request: Request, job_id: int, db: Session = Depends(get_db), user: User = Depends(login_required())):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    if user.role not in {'admin'} and job.employer_id != user.id:
        raise HTTPException(status_code=403, detail="Forbidden")
    if job.status == 'open':
        job.status = 'closed'
        record_event(db, 'job_closed', actor_id=user.id, job_id=job.id)
    else:
        job.status = 'open'
        record_event(db, 'job_opened', actor_id=user.id, job_id=job.id)
    db.commit()
    return RedirectResponse(f"/jobs/{job.id}", status_code=302)

# ---------------- Recruiter: take job ----------------
@app.post("/jobs/{job_id}/take")
async def take_job(request: Request, job_id: int, db: Session = Depends(get_db), user: User = Depends(login_required("recruiter"))):
    job = db.get(Job, job_id)
    if not job or job.status != "open" or job.employer_id == user.id:
        raise HTTPException(status_code=404, detail="Job not available")
    active_count = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==job.id, JobRecruiter.status=="active")).count()
    existing = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==job.id, JobRecruiter.recruiter_id==user.id, JobRecruiter.status=="active")).first()
    if existing:
        return RedirectResponse("/dashboard", status_code=302)
    if active_count >= MAX_RECRUITERS_PER_JOB:
        raise HTTPException(status_code=400, detail="No free slots")
    db.add(JobRecruiter(job_id=job.id, recruiter_id=user.id, status="active", pipeline_status='приглашён'))
    db.commit()
    record_event(db, 'assignment_taken', actor_id=user.id, job_id=job.id, recruiter_id=user.id)
    send_email_safe(job.employer.email, "Новый рекрутер взялся", f"По заявке '{job.title}' подключился рекрутер {user.name}.")
    send_telegram_safe(f"HR Team: рекрутер {user.name} взялся за заявку '{job.title}'")
    return RedirectResponse("/dashboard", status_code=302)

@app.post("/assign/{assign_id}/stage")
async def change_stage(assign_id: int, stage: str = Form(...), db: Session = Depends(get_db), user: User = Depends(login_required())):
    a = db.get(JobRecruiter, assign_id)
    if not a:
        raise HTTPException(status_code=404, detail="not found")
    if user.role == 'recruiter' and a.recruiter_id != user.id:
        raise HTTPException(status_code=403, detail="no access")
    if user.role == 'employer' and a.job.employer_id != user.id:
        raise HTTPException(status_code=403, detail="no access")
    a.pipeline_status = stage
    db.commit()
    return RedirectResponse("/dashboard", status_code=302)

# ---------------- Chat ----------------
@app.get("/chat/{job_id}/{recruiter_id}", response_class=HTMLResponse)
async def chat_page(request: Request, job_id: int, recruiter_id: int, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=302)

    job = db.get(Job, job_id)
    recruiter = db.get(User, recruiter_id)
    if not job or not recruiter or recruiter.role != "recruiter":
        raise HTTPException(status_code=404, detail="Not found")

    is_assigned = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==job.id, JobRecruiter.recruiter_id==recruiter.id, JobRecruiter.status=="active")).first()
    if not is_assigned:
        raise HTTPException(status_code=403, detail="No access to chat")
    if user.id not in {job.employer_id, recruiter.id}:
        raise HTTPException(status_code=403, detail="Not a participant")

    employer = db.get(User, job.employer_id)
    ws_token = make_ws_token(user.id, job.id, recruiter.id)
    return render("chat.html", request, job=job, recruiter=recruiter, employer=employer, ws_token=ws_token)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    token = websocket.query_params.get('token')
    if not token:
        await websocket.close(code=4401)
        return
    try:
        uid, job_id, recruiter_id = verify_ws_token(token)
    except HTTPException:
        await websocket.close(code=4401)
        return

    # local room manager
    class _Room:
        conns: Dict[Tuple[int,int], List[WebSocket]] = {}

        @classmethod
        async def connect(cls, job_id, recruiter_id, ws):
            await ws.accept()
            key = (job_id, recruiter_id)
            cls.conns.setdefault(key, []).append(ws)

        @classmethod
        def disconnect(cls, job_id, recruiter_id, ws):
            key = (job_id, recruiter_id)
            if key in cls.conns and ws in cls.conns[key]:
                cls.conns[key].remove(ws)
                if not cls.conns[key]:
                    del cls.conns[key]

        @classmethod
        async def broadcast_html(cls, job_id, recruiter_id, html):
            key = (job_id, recruiter_id)
            for ws in cls.conns.get(key, []):
                await ws.send_text(html)

    await _Room.connect(job_id, recruiter_id, websocket)

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                data = json.loads(raw)
            except Exception:
                continue
            if data.get('type') != 'message':
                continue
            content = (data.get('content') or '').strip()
            if not content:
                continue
            with SessionLocal() as db:
                job = db.get(Job, job_id)
                recruiter = db.get(User, recruiter_id)
                sender = db.get(User, uid)
                if not job or not recruiter or not sender:
                    continue
                ok = False
                if uid in {job.employer_id, recruiter.id}:
                    is_assigned = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==job.id, JobRecruiter.recruiter_id==recruiter.id, JobRecruiter.status=="active")).first()
                    ok = bool(is_assigned)
                if not ok:
                    continue
                recipient_id = recruiter.id if uid == job.employer_id else job.employer_id
                msg = Message(job_id=job.id, recruiter_id=recruiter.id, sender_id=uid, recipient_id=recipient_id, content=content)
                db.add(msg)
                db.commit()
                record_event(db, 'message', actor_id=uid, job_id=job.id, recruiter_id=recruiter.id)
                to_email = db.get(User, recipient_id).email
                try:
                    send_email_safe(to_email, f"Новое сообщение: {job.title}", f"{sender.name}: {content}")
                except Exception:
                    pass
                send_telegram_safe(f"Сообщение по '{job.title}' от {sender.name}: {content}")
            html = f"""
            <div class=\"mb-2\">
              <div class=\"inline-block px-3 py-2 rounded-xl bg-white border\">
                <div class=\"text-xs opacity-70 mb-1\">Сообщение • {datetime.utcnow().strftime('%H:%M %d.%m')} UTC</div>
                <div class=\"whitespace-pre-line\">{escape_html(content)}</div>
              </div>
            </div>
            """
            await _Room.broadcast_html(job_id, recruiter_id, html)
    except WebSocketDisconnect:
        _Room.disconnect(job_id, recruiter_id, websocket)

@app.get("/api/chat/{job_id}/{recruiter_id}/list")
async def api_chat_list(request: Request, job_id: int, recruiter_id: int, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="auth")
    job = db.get(Job, job_id)
    recruiter = db.get(User, recruiter_id)
    if not job or not recruiter:
        raise HTTPException(status_code=404, detail="notfound")
    is_assigned = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==job.id, JobRecruiter.recruiter_id==recruiter.id, JobRecruiter.status=="active")).first()
    if not is_assigned:
        raise HTTPException(status_code=403, detail="noaccess")
    if user.id not in {job.employer_id, recruiter.id}:
        raise HTTPException(status_code=403, detail="notparticipant")

    msgs = db.query(Message).filter(and_(Message.job_id==job.id, Message.recruiter_id==recruiter.id)).order_by(Message.timestamp.asc()).all()
    parts = []
    for m in msgs:
        mine = (m.sender_id == user.id)
        cls = "text-right" if mine else ""
        bubble = "bg-indigo-600 text-white" if mine else "bg-white border"
        label = "Вы" if mine else ("Собеседник")
        content = escape_html(m.content)
        if m.attachment_id:
            parts.append(f"""
            <div class=\"mb-2 {cls}\">
              <div class=\"inline-block px-3 py-2 rounded-xl {bubble}\">
                <div class=\"text-xs opacity-70 mb-1\">{label} • {m.timestamp.strftime('%H:%M %d.%m')}</div>
                <div class=\"whitespace-pre-line\"><a class='underline' href='/uploads/{m.attachment_id}'>Файл</a></div>
              </div>
            </div>
            """)
        else:
            parts.append(f"""
            <div class=\"mb-2 {cls}\">
              <div class=\"inline-block px-3 py-2 rounded-xl {bubble}\">
                <div class=\"text-xs opacity-70 mb-1\">{label} • {m.timestamp.strftime('%H:%M %d.%m')}</div>
                <div class=\"whitespace-pre-line\">{content}</div>
              </div>
            </div>
            """)
    return HTMLResponse("\n".join(parts))

@app.post("/api/chat/{job_id}/{recruiter_id}/upload")
async def upload_attachment(job_id: int, recruiter_id: int, request: Request, f: UploadFile = File(...), db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        raise HTTPException(status_code=401)
    job = db.get(Job, job_id)
    recruiter = db.get(User, recruiter_id)
    if not job or not recruiter:
        raise HTTPException(status_code=404)
    is_assigned = db.query(JobRecruiter).filter(and_(JobRecruiter.job_id==job.id, JobRecruiter.recruiter_id==recruiter.id, JobRecruiter.status=="active")).first()
    if not is_assigned or user.id not in {job.employer_id, recruiter.id}:
        raise HTTPException(status_code=403)

    ext = os.path.splitext(f.filename)[1]
    fname = f"{uuid.uuid4().hex}{ext}"
    dest = os.path.join(UPLOAD_DIR, fname)
    with open(dest, 'wb') as out:
        shutil.copyfileobj(f.file, out)

    att = Attachment(filename=f.filename, path=fname, uploader_id=user.id)
    db.add(att); db.commit()

    msg = Message(job_id=job.id, recruiter_id=recruiter.id, sender_id=user.id,
                  recipient_id=(recruiter.id if user.id==job.employer_id else job.employer_id),
                  content=f"[Файл: {f.filename}]", attachment_id=att.id)
    db.add(msg); db.commit()
    record_event(db, 'message', actor_id=user.id, job_id=job.id, recruiter_id=recruiter.id)

    placeholder = f"Файл: {f.filename} — /uploads/{att.path}"
    return JSONResponse({"ok": True, "placeholder": placeholder, "id": att.id})

@app.get("/uploads/{att_id}")
async def get_upload(att_id: int, db: Session = Depends(get_db)):
    att = db.get(Attachment, att_id)
    if not att:
        raise HTTPException(status_code=404)
    return RedirectResponse(url=f"/uploads/{att.path}")



# ---------------- Utilities: health & exports ----------------
@app.get("/healthz")
async def healthz():
    return JSONResponse({"ok": True, "time": datetime.utcnow().isoformat() + "Z"})

import io, csv

@app.get("/admin/export/users.csv")
async def export_users_csv(db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    buf = io.StringIO(newline="")
    writer = csv.writer(buf)
    writer.writerow(["id","name","email","role","is_active","created_at"])
    for u in db.query(User).order_by(User.created_at.asc()).all():
        writer.writerow([u.id, u.name, u.email, u.role, 1 if u.is_active else 0, (u.created_at or datetime.utcnow()).isoformat()])
    return Response(content=buf.getvalue(), media_type="text/csv", headers={"Content-Disposition":"attachment; filename=users.csv"})

@app.get("/admin/export/jobs.csv")
async def export_jobs_csv(db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    buf = io.StringIO(newline="")
    writer = csv.writer(buf)
    writer.writerow(["id","title","reward","city","level","is_remote","tags","status","employer_email","created_at"])
    for j in db.query(Job).order_by(Job.created_at.asc()).all():
        employer_email = j.employer.email if j.employer else ""
        writer.writerow([j.id, j.title, j.reward, j.city or "", j.level or "", 1 if j.is_remote else 0, j.tags or "", j.status, employer_email, (j.created_at or datetime.utcnow()).isoformat()])
    return Response(content=buf.getvalue(), media_type="text/csv", headers={"Content-Disposition":"attachment; filename=jobs.csv"})

# ---------------- Admin ----------------
@app.get("/admin", response_class=HTMLResponse)
async def admin_home(request: Request, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    p = db.query(Job).filter(Job.status=="pending").order_by(Job.created_at.desc()).all()
    for j in p:
        j.reward_fmt = fmt_money(j.reward)
    users = db.query(User).order_by(User.created_at.desc()).all()
    invoices = db.query(Invoice).order_by(Invoice.created_at.desc()).all()
    employers = db.query(User).filter(User.role=="employer", User.is_active==True).all()
    pages = db.query(Page).order_by(Page.slug.asc()).all()
    return render("admin.html", request, pending_jobs=p, users=users, invoices=invoices, employers=employers, pages=pages)

@app.post("/admin/job/{job_id}/approve")
async def admin_approve_job(job_id: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    job = db.get(Job, job_id)
    if not job: raise HTTPException(status_code=404)
    job.status = 'open'; db.commit()
    record_event(db, 'job_opened', actor_id=user.id, job_id=job.id)
    send_email_safe(job.employer.email, "Заявка одобрена", f"Ваша заявка '{job.title}' одобрена и опубликована")
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/job/{job_id}/reject")
async def admin_reject_job(job_id: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    job = db.get(Job, job_id)
    if not job: raise HTTPException(status_code=404)
    job.status = 'closed'; db.commit()
    record_event(db, 'job_closed', actor_id=user.id, job_id=job.id)
    send_email_safe(job.employer.email, "Заявка отклонена", f"Ваша заявка '{job.title}' отклонена администратором")
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/user/{uid}/block")
async def admin_block_user(uid: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    u = db.get(User, uid)
    if not u: raise HTTPException(status_code=404)
    u.is_active = False; db.commit()
    record_event(db, 'user_blocked', actor_id=user.id)
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/user/{uid}/unblock")
async def admin_unblock_user(uid: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    u = db.get(User, uid)
    if not u: raise HTTPException(status_code=404)
    u.is_active = True; db.commit()
    record_event(db, 'user_unblocked', actor_id=user.id)
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/invoices/new")
async def admin_new_invoice(employer_id: int = Form(...), amount: float = Form(...), description: str = Form(""),
                            db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    inv = Invoice(employer_id=employer_id, amount=float(amount), description=description.strip(), status='sent')
    db.add(inv); db.commit()
    record_event(db, 'invoice_sent', actor_id=user.id, invoice_id=inv.id)
    emp = db.get(User, employer_id)
    send_email_safe(emp.email, "Вам выставлен инвойс", f"Инвойс #{inv.id} на сумму {inv.amount} {inv.currency}. Описание: {inv.description}")
    send_telegram_safe(f"Инвойс #{inv.id} для {emp.email} на {inv.amount} {inv.currency}")
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/invoices/{inv_id}/mark-paid")
async def admin_invoice_paid(inv_id: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    inv = db.get(Invoice, inv_id)
    if not inv: raise HTTPException(status_code=404)
    inv.status = 'paid'; inv.paid_at = datetime.utcnow(); db.commit()
    record_event(db, 'invoice_paid', actor_id=user.id, invoice_id=inv.id)
    return RedirectResponse("/admin", status_code=302)

# Admin: drop recruiter from a job
@app.post("/admin/assign/{assign_id}/drop")
async def admin_drop_recruiter(assign_id: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    a = db.get(JobRecruiter, assign_id)
    if not a: raise HTTPException(status_code=404, detail="assign not found")
    a.status = "dropped"; db.commit()
    record_event(db, 'recruiter_dropped', actor_id=user.id, job_id=a.job_id, recruiter_id=a.recruiter_id)
    return RedirectResponse(f"/jobs/{a.job_id}", status_code=302)

# ---------------- PAGES (CMS) ----------------
def ensure_default_pages(db: Session):
    defaults = [
        ("rules", "Правила сайта", "Здесь будут ваши правила сайта. Замените этот текст в админке → Страницы."),
        ("terms", "Условия пользования", "Здесь разместите условия пользования сервисом."),
        ("privacy", "Политика конфиденциальности", "Опишите политику обработки персональных данных."),
        ("about", "О сервисе", "Коротко расскажите о площадке и принципах работы."),
    ]
    for slug, title, content in defaults:
        if not db.query(Page).filter_by(slug=slug).first():
            db.add(Page(slug=slug, title=title, content=content, is_public=True))
    db.commit()

@app.get("/page/{slug}", response_class=HTMLResponse)
async def page_view(slug: str, request: Request, db: Session = Depends(get_db)):
    ensure_default_pages(db)
    p = db.query(Page).filter_by(slug=slug).first()
    if not p or (not p.is_public):
        raise HTTPException(status_code=404, detail="page not found")
    return render("page_view.html", request, page=p, title=p.title)
@app.get("/admin/pages", response_class=HTMLResponse)
async def pages_list(request: Request, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    pages = db.query(Page).order_by(Page.slug.asc()).all()
    return render("pages_admin_list.html", request, pages=pages)

@app.get("/admin/pages/new", response_class=HTMLResponse)
async def page_new_form(request: Request, user: User = Depends(login_required("admin"))):
    return render("page_edit.html", request, page=None)

@app.post("/admin/pages/new")
async def page_new(request: Request,
                   slug: str = Form(...), title: str = Form(...), content: str = Form(""), is_public: Optional[str] = Form(None),
                   db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    slug = slug.strip().lower()
    if not slug.replace("-", "").replace("_", "").isalnum():
        return render("page_edit.html", request, page=None, error="Slug должен быть латиницей/цифрами, допускаются - и _")
    if db.query(Page).filter_by(slug=slug).first():
        return render("page_edit.html", request, page=None, error="Такой slug уже существует")
    p = Page(slug=slug, title=title.strip(), content=content, is_public=bool(is_public=="1"))
    db.add(p); db.commit()
    return RedirectResponse("/admin/pages", status_code=302)

@app.get("/admin/pages/{pid}/edit", response_class=HTMLResponse)
async def page_edit_form(pid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    p = db.get(Page, pid)
    if not p: raise HTTPException(status_code=404)
    return render("page_edit.html", request, page=p)

@app.post("/admin/pages/{pid}/edit")
async def page_edit(pid: int,
                    slug: str = Form(...), title: str = Form(...), content: str = Form(""), is_public: Optional[str] = Form(None),
                    db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    p = db.get(Page, pid)
    if not p: raise HTTPException(status_code=404)
    new_slug = slug.strip().lower()
    if not new_slug.replace("-", "").replace("_", "").isalnum():
        return render("page_edit.html", request, page=p, error="Slug должен быть латиницей/цифрами, допускаются - и _")
    if new_slug != p.slug and db.query(Page).filter_by(slug=new_slug).first():
        return render("page_edit.html", request, page=p, error="Такой slug уже существует")
    p.slug = new_slug
    p.title = title.strip()
    p.content = content
    p.is_public = bool(is_public=="1")
    db.commit()
    return RedirectResponse("/admin/pages", status_code=302)

@app.post("/admin/pages/{pid}/delete")
async def page_delete(pid: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    p = db.get(Page, pid)
    if not p: raise HTTPException(status_code=404)
    db.delete(p); db.commit()
    return RedirectResponse("/admin/pages", status_code=302)

# ---------------- FAQ ----------------
def ensure_default_faq(db: Session):
    if db.query(FaqItem).count() == 0:
        samples = [
            ("Как рекрутер берёт в работу заявку?", "Зайдите в Панель → \"Доступные заявки\" и нажмите «Взяться». На одну заявку допускается до %d рекрутеров." % MAX_RECRUITERS_PER_JOB),
            ("Как отправить резюме/файл?", "Откройте чат по заявке и прикрепите файл через иконку 📎."),
            ("Можно ли заблокировать пользователя-нарушителя?", "Да. Администратор может заблокировать любого пользователя в разделе Админка → Пользователи."),
            ("Где найти правила и условия?", "Смотрите страницы: «Правила», «Условия», «Политика конфиденциальности» в шапке и подвале сайта."),
        ]
        for i, (q, a) in enumerate(samples, start=1):
            db.add(FaqItem(question=q, answer=a, rank=i, is_public=True))
        db.commit()

@app.get("/faq", response_class=HTMLResponse)
async def faq_public(request: Request, db: Session = Depends(get_db)):
    ensure_default_faq(db)
    items = db.query(FaqItem).filter_by(is_public=True).order_by(FaqItem.rank.asc(), FaqItem.created_at.asc()).all()
    return render("faq_public.html", request, items=items, title="FAQ")

@app.get("/admin/faq", response_class=HTMLResponse)
async def faq_admin_list(request: Request, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    items = db.query(FaqItem).order_by(FaqItem.rank.asc(), FaqItem.created_at.asc()).all()
    return render("faq_admin.html", request, items=items)

@app.get("/admin/faq/new", response_class=HTMLResponse)
async def faq_new_form(request: Request, user: User = Depends(login_required("admin"))):
    return render("faq_edit.html", request, item=None)

@app.post("/admin/faq/new")
async def faq_new(question: str = Form(...), answer: str = Form(...), rank: int = Form(0),
                  is_public: Optional[str] = Form(None), db: Session = Depends(get_db),
                  user: User = Depends(login_required("admin"))):
    item = FaqItem(question=question.strip(), answer=answer.strip(), rank=int(rank or 0), is_public=bool(is_public=="1"))
    db.add(item); db.commit()
    return RedirectResponse("/admin/faq", status_code=302)

@app.get("/admin/faq/{fid}/edit", response_class=HTMLResponse)
async def faq_edit_form(fid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    item = db.get(FaqItem, fid)
    if not item: raise HTTPException(status_code=404)
    return render("faq_edit.html", request, item=item)

@app.post("/admin/faq/{fid}/edit")
async def faq_edit(fid: int,
                   question: str = Form(...), answer: str = Form(...), rank: int = Form(0),
                   is_public: Optional[str] = Form(None), db: Session = Depends(get_db),
                   user: User = Depends(login_required("admin"))):
    item = db.get(FaqItem, fid)
    if not item: raise HTTPException(status_code=404)
    item.question = question.strip()
    item.answer = answer.strip()
    item.rank = int(rank or 0)
    item.is_public = bool(is_public=="1")
    db.commit()
    return RedirectResponse("/admin/faq", status_code=302)

@app.post("/admin/faq/{fid}/delete")
async def faq_delete(fid: int, db: Session = Depends(get_db), user: User = Depends(login_required("admin"))):
    item = db.get(FaqItem, fid)
    if not item: raise HTTPException(status_code=404)
    db.delete(item); db.commit()
    return RedirectResponse("/admin/faq", status_code=302)

# ==========================================================================
#                          STARTUP: bootstrap admin & defaults
# ==========================================================================
@app.on_event("startup")
def bootstrap():
    with SessionLocal() as db:
        has_admin = db.query(User).filter(User.role=="admin").first()
        if not has_admin:
            admin = User(name="Admin", email="admin@otvet.kz", password_hash=hasher.hash("admin"), role="admin", is_active=True, is_verified=True, accepted_terms_at=datetime.utcnow())
            db.add(admin); db.commit()
        ensure_default_pages(db)
        ensure_default_faq(db)

# ==========================================================================
#                       RUN HINTS / DOCKER (comments)
# ==========================================================================
# Run (dev):
#   pip install fastapi uvicorn[standard] sqlalchemy passlib jinja2 python-multipart itsdangerous requests
#   uvicorn app_full:app --reload --port 8000
#
# Notes:
# - Пароли теперь на pbkdf2_sha256 (без проблемных системных колёс bcrypt).
# - Для продакшена: HTTPS, полноценный ACL, CSRF для POST-форм, ограничение размера/типа файлов, вирус-скан, объектное хранилище,
#   отдельные роли модераторов, audit-лог в БД, rate-limit, капча.
#
# Dockerfile (пример):
# FROM python:3.11-slim
# WORKDIR /app
# COPY ./app_full.py /app/app_full.py
# RUN pip install --no-cache-dir fastapi uvicorn[standard] sqlalchemy passlib jinja2 python-multipart itsdangerous requests
# ENV DB_URL=sqlite:///market.db SECRET_KEY=change-me
# EXPOSE 8000
# CMD ["uvicorn", "app_full:app", "--host", "0.0.0.0", "--port", "8000"]
