from typing import Optional, Callable
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User  # подставь правильную модель пользователя, если имя другое

def current_user(
    request: Request,
    db: Session = Depends(get_db),
) -> Optional[User]:
    """
    Возвращает текущего пользователя из сессии или None.
    ВАЖНО: db берём только через Depends(get_db), нигде не оставляем "db: Session" без Depends!
    """
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    return db.get(User, user_id)

def login_required(role: Optional[str] = None) -> Callable[..., User]:
    """
    Фабрика зависимостей. Использование: Depends(login_required("admin"))
    Внутри — зависимость на current_user, который уже тянет db через Depends(get_db).
    """
    def _dep(user: Optional[User] = Depends(current_user)) -> User:
        if not user:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
        if role and getattr(user, "role", None) != role:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN)
        return user
    return _dep
