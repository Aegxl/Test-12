from fastapi import FastAPI
from .auth import router as auth_router
from .dashboard import router as dashboard_router
from .jobs import router as jobs_router
from .chat import router as chat_router
from .admin import router as admin_router
from .cms import router as cms_router


def include_routers(app: FastAPI):
    """Include all routers in the app"""
    app.include_router(auth_router)
    app.include_router(dashboard_router)
    app.include_router(jobs_router)
    app.include_router(chat_router)
    app.include_router(admin_router)
    app.include_router(cms_router)