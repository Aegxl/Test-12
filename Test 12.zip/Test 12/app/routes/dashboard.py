"""
Dashboard routes
"""
import json
from datetime import datetime
from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import and_
from sqlalchemy.orm import Session

from app.database import get_db, SessionLocal
from app.models import Job, JobRecruiter, Event
from app.templates import get_jinja_env
from app.dependencies import current_user, login_required
from app.utils import fmt_money
from app.config import MAX_RECRUITERS_PER_JOB

router = APIRouter()
env = get_jinja_env()


def render(name: str, request: Request, **context) -> HTMLResponse:
    """Render template with context"""
    with SessionLocal() as db:
        user = current_user(request, db)
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow(),
        "max_recr": MAX_RECRUITERS_PER_JOB,
        **context
    })
    return HTMLResponse(html)


def fmt_event(e: Event):
    """Format event for display"""
    try:
        meta = json.loads(e.meta) if e.meta else {}
    except Exception:
        meta = {}

    mapping = {
        'job_created': f"Создана заявка #{meta.get('job_id')}",
        'job_opened': f"Открыта заявка #{meta.get('job_id')}",
        'job_closed': f"Закрыта заявка #{meta.get('job_id')}",
        'assignment_taken': f"Рекрутер взялся за заявку #{meta.get('job_id')}",
        'message': f"Новое сообщение по заявке #{meta.get('job_id')}",
        'invoice_sent': f"Выставлен инвойс #{meta.get('invoice_id')}",
        'invoice_paid': f"Оплачен инвойс #{meta.get('invoice_id')}",
        'user_blocked': f"Пользователь заблокирован",
        'user_unblocked': f"Пользователь разблокирован",
        'recruiter_dropped': f"Рекрутер удалён из заявки #{meta.get('job_id')}",
    }

    return type("EObj", (), {
        "created_at": e.created_at,
        "text": mapping.get(e.type, e.type)
    })


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=302)

    if user.role == "employer":
        # Employer dashboard
        jobs = db.query(Job).filter(Job.employer_id == user.id).order_by(Job.created_at.desc()).all()
        for j in jobs:
            j.reward_fmt = fmt_money(j.reward)

        # Get events related to employer's jobs
        ev = db.query(Event).filter(
            Event.job_id.in_([j.id for j in jobs]) if jobs else Event.id == Event.id
        ).order_by(Event.created_at.desc()).limit(20).all()
        events = [fmt_event(e) for e in ev]

        return render("dashboard_employer.html", request, jobs=jobs, events=events)

    elif user.role == "recruiter":
        # Recruiter dashboard with filters
        city = (request.query_params.get('city') or '').strip()
        level = (request.query_params.get('level') or '').strip()
        remote = request.query_params.get('remote') == '1'
        tags = (request.query_params.get('tags') or '').strip()

        # Build query for open jobs
        q = db.query(Job).filter(Job.status == "open")
        if city:
            q = q.filter(Job.city.ilike(f"%{city}%"))
        if level:
            q = q.filter(Job.level == level)
        if remote:
            q = q.filter(Job.is_remote == True)
        if tags:
            for t in [t.strip() for t in tags.split(',') if t.strip()]:
                q = q.filter(Job.tags.ilike(f"%{t}%"))

        # Filter available jobs (not full, not already assigned to this recruiter, not own jobs)
        open_jobs = []
        for j in q.order_by(Job.created_at.desc()).all():
            active_count = db.query(JobRecruiter).filter(
                and_(JobRecruiter.job_id == j.id, JobRecruiter.status == "active")
            ).count()
            already = db.query(JobRecruiter).filter(
                and_(JobRecruiter.job_id == j.id, JobRecruiter.recruiter_id == user.id, JobRecruiter.status == "active")
            ).first()

            if active_count < MAX_RECRUITERS_PER_JOB and not already and j.employer_id != user.id:
                j.reward_fmt = fmt_money(j.reward)
                j.free_slots = MAX_RECRUITERS_PER_JOB - active_count
                open_jobs.append(j)

        # Get recruiter's assignments
        my_assignments = db.query(JobRecruiter).filter(
            and_(JobRecruiter.recruiter_id == user.id, JobRecruiter.status == "active")
        ).order_by(JobRecruiter.assigned_at.desc()).all()

        # Recent events
        ev = db.query(Event).order_by(Event.created_at.desc()).limit(20).all()
        events = [fmt_event(e) for e in ev]

        return render("dashboard_recruiter.html", request,
                     open_jobs=open_jobs,
                     my_assignments=my_assignments,
                     max_recr=MAX_RECRUITERS_PER_JOB,
                     filters={"city": city, "level": level, "remote": remote, "tags": tags},
                     events=events)

    else:
        # Admin role - redirect to admin panel
        return RedirectResponse("/admin", status_code=302)