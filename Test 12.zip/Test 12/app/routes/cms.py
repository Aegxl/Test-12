from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Page, FaqItem
from app.utils import render
from app.dependencies import current_user, login_required
from app.config import MAX_RECRUITERS_PER_JOB

router = APIRouter()

@router.get("/page/{slug}")
async def page_legacy(slug: str):
    return RedirectResponse(f"/p/{slug}", status_code=302)


DEFAULT_PAGES = {
    "rules": ("Правила площадки", "Здесь будут опубликованы правила использования площадки."),
    "terms": ("Условия сервиса", "Базовые условия обслуживания и возмещения. Тестовый текст-заглушка."),
    "privacy": ("Политика конфиденциальности", "Мы ценим вашу приватность. Здесь появится подробная политика."),
    "about": ("О сервисе", "Коротко о проекте: маркетплейс заявок на подбор персонала."),
}

def ensure_defaults(db: Session) -> None:
    for slug, (title, content) in DEFAULT_PAGES.items():
        if not db.query(Page).filter_by(slug=slug).first():
            db.add(Page(slug=slug, title=title, content=content, is_public=True))
    if db.query(FaqItem).count() == 0:
        samples = [
            ("Как рекрутер берёт в работу заявку?", f"До {MAX_RECRUITERS_PER_JOB} рекрутеров на заявку. Нажмите «Взяться»."),
            ("Как отправить резюме/файл?", "Откройте чат по заявке и прикрепите файл."),
            ("Где найти правила и условия?", "Смотрите страницы: «Правила», «Условия», «Политика конфиденциальности»."),
        ]
        for i, (q, a) in enumerate(samples, start=1):
            db.add(FaqItem(question=q, answer=a, rank=i, is_public=True))
    db.commit()

@router.get("/p/{slug}", response_class=HTMLResponse, response_model=None)
async def page_view(
    slug: str,
    request: Request,
    db: Session = Depends(get_db),
    user = Depends(current_user),
):
    ensure_defaults(db)
    page = db.query(Page).filter_by(slug=slug, is_public=True).first()
    if not page:
        page = Page(slug=slug, title=slug.title(), content="Контент готовится. Текст-заглушка.", is_public=True)
        db.add(page)
        db.commit()
        db.refresh(page)
    return render("page_view.html", request, user=user, page=page, title=page.title)

@router.get("/privacy", response_model=None)
async def privacy_redirect():
    return RedirectResponse("/p/privacy", status_code=302)

@router.get("/terms", response_model=None)
async def terms_redirect():
    return RedirectResponse("/p/terms", status_code=302)

@router.get("/rules", response_model=None)
async def rules_redirect():
    return RedirectResponse("/p/rules", status_code=302)

@router.get("/about", response_model=None)
async def about_redirect():
    return RedirectResponse("/p/about", status_code=302)

@router.get("/faq", response_class=HTMLResponse, response_model=None)
async def faq_list(
    request: Request,
    db: Session = Depends(get_db),
    user = Depends(current_user),
):
    ensure_defaults(db)
    items = db.query(FaqItem).filter(FaqItem.is_public == True).order_by(FaqItem.rank.asc()).all()
    content = "\n".join(
        [f"<details class='mb-2'><summary>{i.question}</summary><div>{i.answer}</div></details>" for i in items]
    ) or "Пока вопросов нет."
    page = Page(slug="faq", title="FAQ", content=content, is_public=True)
    return render("page_view.html", request, user=user, page=page, title="FAQ")

@router.get("/admin/pages", response_class=HTMLResponse, response_model=None)
async def pages_admin_list(
    request: Request,
    db: Session = Depends(get_db),
    user = Depends(login_required("admin")),
):
    pages = db.query(Page).order_by(Page.slug.asc()).all()
    return render("pages_admin_list.html", request, user=user, pages=pages)

@router.get("/admin/pages/new", response_class=HTMLResponse, response_model=None)
async def page_new_form(
    request: Request,
    user = Depends(login_required("admin")),
):
    return render("page_edit.html", request, user=user, page=None, error=None)

@router.post("/admin/pages/new", response_model=None)
async def page_new(
    request: Request,
    slug: str = Form(...),
    title: str = Form(...),
    content: str = Form(""),
    is_public: str = Form("1"),
    db: Session = Depends(get_db),
    user = Depends(login_required("admin")),
):
    if db.query(Page).filter_by(slug=slug).first():
        return render("page_edit.html", request, user=user, page=None, error="Такой slug уже существует")
    p = Page(slug=slug.strip(), title=title.strip(), content=content, is_public=(is_public == "1"))
    db.add(p)
    db.commit()
    return RedirectResponse("/admin/pages", status_code=302)

@router.get("/admin/pages/{pid}/edit", response_class=HTMLResponse, response_model=None)
async def page_edit_form(
    pid: int,
    request: Request,
    db: Session = Depends(get_db),
    user = Depends(login_required("admin")),
):
    p = db.get(Page, pid)
    if not p:
        raise HTTPException(status_code=404)
    return render("page_edit.html", request, user=user, page=p, error=None)

@router.post("/admin/pages/{pid}/edit", response_model=None)
async def page_edit(
    pid: int,
    request: Request,
    slug: str = Form(...),
    title: str = Form(...),
    content: str = Form(""),
    is_public: str = Form("1"),
    db: Session = Depends(get_db),
    user = Depends(login_required("admin")),
):
    p = db.get(Page, pid)
    if not p:
        raise HTTPException(status_code=404)
    p.slug = slug.strip()
    p.title = title.strip()
    p.content = content
    p.is_public = (is_public == "1")
    db.commit()
    return RedirectResponse("/admin/pages", status_code=302)

@router.post("/admin/pages/{pid}/delete", response_model=None)
async def page_delete(
    pid: int,
    db: Session = Depends(get_db),
    user = Depends(login_required("admin")),
):
    p = db.get(Page, pid)
    if not p:
        raise HTTPException(status_code=404)
    db.delete(p)
    db.commit()
    return RedirectResponse("/admin/pages", status_code=302)
