"""
Job management routes
"""
from datetime import datetime
from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import and_
from sqlalchemy.orm import Session

from app.database import get_db, SessionLocal
from app.models import Job, JobRecruiter
from app.templates import get_jinja_env
from app.dependencies import current_user, login_required
from app.utils import fmt_money, record_event, send_email_safe, send_telegram_safe
from app.config import MAX_RECRUITERS_PER_JOB

router = APIRouter()
env = get_jinja_env()


def render(name: str, request: Request, **context) -> HTMLResponse:
    """Render template with context"""
    with SessionLocal() as db:
        user = current_user(request, db)
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow(),
        "max_recr": MAX_RECRUITERS_PER_JOB,
        **context
    })
    return HTMLResponse(html)


@router.get("/jobs/new", response_class=HTMLResponse)
async def job_new_form(request: Request, user=Depends(login_required("employer"))):
    return render("job_new.html", request)


@router.post("/jobs/new")
async def job_new(
        request: Request,
        title: str = Form(...),
        description: str = Form(...),
        reward: float = Form(...),
        city: str = Form(""),
        level: str = Form(""),
        is_remote: str = Form("0"),
        tags: str = Form(""),
        employment_type: str = Form(""),
        remote_type: str = Form(""),
        schedule: str = Form(""),
        openings: int = Form(0),
        experience_years: int = Form(0),
        education: str = Form(""),
        languages: str = Form(""),
        probation: str = Form(""),
        deadline: str = Form(""),
        contact_email: str = Form(""),
        contact_phone: str = Form(""),
        office_address: str = Form(""),
        notes: str = Form(""),
        db: Session = Depends(get_db),
        user=Depends(login_required("employer"))
):
    title = title.strip()
    description = description.strip()
    # Assemble extended tags (backward-compatible)
    _kv = []
    def _add(k, v):
        v = (v or "").strip()
        if isinstance(v, (int, float)) and not v:
            v = ""
        if v != "0" and v != "":
            _kv.append(f"{k}:{v}")
    _add("employment_type", employment_type)
    _add("remote_type", remote_type)
    _add("schedule", schedule)
    _add("openings", openings)
    _add("experience_years", experience_years)
    _add("education", education)
    _add("languages", languages)
    _add("probation", probation)
    _add("deadline", deadline)
    _add("contact_email", contact_email)
    _add("contact_phone", contact_phone)
    _add("office_address", office_address)
    _add("notes", notes)
    tags = ", ".join([s.strip() for s in (tags or "").split(",") if s.strip()] + _kv)


    try:
        reward_val = float(reward)
    except Exception:
        return render("job_new.html", request, error="Некорректная сумма")

    job = Job(
        title=title,
        description=description,
        reward=reward_val,
        employer_id=user.id,
        city=city.strip(),
        level=(level or '').strip(),
        is_remote=(is_remote == '1'),
        tags=(tags or '').strip(),
        status='pending'
    )
    db.add(job)
    db.commit()

    record_event(db, 'job_created', actor_id=user.id, job_id=job.id)
    return RedirectResponse(f"/jobs/{job.id}?created=1", status_code=302)


@router.get("/jobs/{job_id}", response_class=HTMLResponse)
async def job_detail(
        request: Request,
        job_id: int,
        db: Session = Depends(get_db),
        user=Depends(login_required())
):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    if user.role != 'admin' and job.employer_id != user.id:
        raise HTTPException(status_code=403, detail="Forbidden")

    job.reward_fmt = fmt_money(job.reward)
    assignments = db.query(JobRecruiter).filter(
        and_(JobRecruiter.job_id == job.id, JobRecruiter.status == "active")
    ).all()

    can_toggle = (user.role in {'admin'})
    return render("job_detail.html", request,
                  job=job,
                  assignments=assignments,
                  max_recr=MAX_RECRUITERS_PER_JOB,
                  can_toggle=can_toggle,
                  is_admin=(user.role == 'admin'))


@router.post("/jobs/{job_id}/toggle")
async def job_toggle(
        request: Request,
        job_id: int,
        db: Session = Depends(get_db),
        user=Depends(login_required())
):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    if user.role not in {'admin'}:
        raise HTTPException(status_code=403, detail="Forbidden")

    if job.status == 'open':
        job.status = 'closed'
        record_event(db, 'job_closed', actor_id=user.id, job_id=job.id)
    else:
        job.status = 'open'
        record_event(db, 'job_opened', actor_id=user.id, job_id=job.id)

    db.commit()
    return RedirectResponse(f"/jobs/{job.id}?created=1", status_code=302)


@router.post("/jobs/{job_id}/take")
async def take_job(
        request: Request,
        job_id: int,
        db: Session = Depends(get_db),
        user=Depends(login_required("recruiter"))
):
    job = db.get(Job, job_id)
    if not job or job.status != "open" or job.employer_id == user.id:
        raise HTTPException(status_code=404, detail="Job not available")

    # Check if job has free slots
    active_count = db.query(JobRecruiter).filter(
        and_(JobRecruiter.job_id == job.id, JobRecruiter.status == "active")
    ).count()

    # Check if recruiter already assigned
    existing = db.query(JobRecruiter).filter(
        and_(JobRecruiter.job_id == job.id, JobRecruiter.recruiter_id == user.id, JobRecruiter.status == "active")
    ).first()

    if existing:
        return RedirectResponse("/dashboard", status_code=302)

    if active_count >= MAX_RECRUITERS_PER_JOB:
        raise HTTPException(status_code=400, detail="No free slots")

    # Create assignment
    db.add(JobRecruiter(
        job_id=job.id,
        recruiter_id=user.id,
        status="active",
        pipeline_status='приглашён'
    ))
    db.commit()

    # Record event and send notifications
    record_event(db, 'assignment_taken', actor_id=user.id, job_id=job.id, recruiter_id=user.id)
    send_email_safe(job.employer.email, "Новый рекрутер взялся",
                    f"По заявке '{job.title}' подключился рекрутер {user.name}.")
    send_telegram_safe(f"HR Team: рекрутер {user.name} взялся за заявку '{job.title}'")

    return RedirectResponse("/dashboard", status_code=302)


@router.post("/assign/{assign_id}/stage")
async def change_stage(
        assign_id: int,
        stage: str = Form(...),
        db: Session = Depends(get_db),
        user=Depends(login_required())
):
    a = db.get(JobRecruiter, assign_id)
    if not a:
        raise HTTPException(status_code=404, detail="not found")

    # Check permissions
    if user.role == 'recruiter' and a.recruiter_id != user.id:
        raise HTTPException(status_code=403, detail="no access")
    if user.role == 'employer' and a.job.employer_id != user.id:
        raise HTTPException(status_code=403, detail="no access")

    a.pipeline_status = stage
    db.commit()
    return RedirectResponse("/dashboard", status_code=302)