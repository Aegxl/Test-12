"""
Admin panel routes
"""
import io
import csv
from datetime import datetime
from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlalchemy.orm import Session

from app.database import get_db, SessionLocal
from app.models import Job, User, JobRecruiter, Invoice, Page
from app.templates import get_jinja_env
from app.dependencies import current_user, login_required
from app.utils import fmt_money, record_event, send_email_safe, send_telegram_safe
from app.config import MAX_RECRUITERS_PER_JOB

router = APIRouter()
env = get_jinja_env()


def render(name: str, request: Request, **context) -> HTMLResponse:
    """Render template with context"""
    with SessionLocal() as db:
        user = current_user(request, db)
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow(),
        "max_recr": MAX_RECRUITERS_PER_JOB,
        **context
    })
    return HTMLResponse(html)


@router.get("/admin", response_class=HTMLResponse)
async def admin_home(
        request: Request,
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    # Pending jobs
    p = db.query(Job).filter(Job.status == "pending").order_by(Job.created_at.desc()).all()
    for j in p:
        j.reward_fmt = fmt_money(j.reward)

    # Users
    users = db.query(User).order_by(User.created_at.desc()).all()

    # Invoices
    invoices = db.query(Invoice).order_by(Invoice.created_at.desc()).all()

    # Employers for invoice creation
    employers = db.query(User).filter(User.role == "employer", User.is_active == True).all()

    # Pages
    pages = db.query(Page).order_by(Page.slug.asc()).all()

    return render("admin.html", request,
                  pending_jobs=p,
                  users=users,
                  invoices=invoices,
                  employers=employers,
                  pages=pages)


@router.post("/admin/job/{job_id}/approve")
async def admin_approve_job(
        job_id: int,
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404)

    job.status = 'open'
    db.commit()

    record_event(db, 'job_opened', actor_id=user.id, job_id=job.id)
    send_email_safe(job.employer.email, "Заявка одобрена", f"Ваша заявка '{job.title}' одобрена и опубликована")

    return RedirectResponse("/admin", status_code=302)


@router.post("/admin/job/{job_id}/reject")
async def admin_reject_job(
        job_id: int,
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    job = db.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404)

    job.status = 'closed'
    db.commit()

    record_event(db, 'job_closed', actor_id=user.id, job_id=job.id)
    send_email_safe(job.employer.email, "Заявка отклонена", f"Ваша заявка '{job.title}' отклонена администратором")

    return RedirectResponse("/admin", status_code=302)


@router.post("/admin/user/{uid}/block")
async def admin_block_user(
        uid: int,
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(status_code=404)

    u.is_active = False
    db.commit()

    record_event(db, 'user_blocked', actor_id=user.id)
    return RedirectResponse("/admin", status_code=302)


@router.post("/admin/user/{uid}/unblock")
async def admin_unblock_user(
        uid: int,
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(status_code=404)

    u.is_active = True
    db.commit()

    record_event(db, 'user_unblocked', actor_id=user.id)
    return RedirectResponse("/admin", status_code=302)


@router.post("/admin/invoices/new")
async def admin_new_invoice(
        employer_id: int = Form(...),
        amount: float = Form(...),
        description: str = Form(""),
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    inv = Invoice(
        employer_id=employer_id,
        amount=float(amount),
        description=description.strip(),
        status='sent'
    )
    db.add(inv)
    db.commit()

    record_event(db, 'invoice_sent', actor_id=user.id, invoice_id=inv.id)

    emp = db.get(User, employer_id)
    send_email_safe(emp.email, "Вам выставлен инвойс",
                    f"Инвойс #{inv.id} на сумму {inv.amount} {inv.currency}. Описание: {inv.description}")
    send_telegram_safe(f"Инвойс #{inv.id} для {emp.email} на {inv.amount} {inv.currency}")

    return RedirectResponse("/admin", status_code=302)


@router.post("/admin/invoices/{inv_id}/mark-paid")
async def admin_invoice_paid(
        inv_id: int,
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    inv = db.get(Invoice, inv_id)
    if not inv:
        raise HTTPException(status_code=404)

    inv.status = 'paid'
    inv.paid_at = datetime.utcnow()
    db.commit()

    record_event(db, 'invoice_paid', actor_id=user.id, invoice_id=inv.id)
    return RedirectResponse("/admin", status_code=302)


@router.post("/admin/assign/{assign_id}/drop")
async def admin_drop_recruiter(
        assign_id: int,
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    a = db.get(JobRecruiter, assign_id)
    if not a:
        raise HTTPException(status_code=404, detail="assign not found")

    a.status = "dropped"
    db.commit()

    record_event(db, 'recruiter_dropped', actor_id=user.id, job_id=a.job_id, recruiter_id=a.recruiter_id)
    return RedirectResponse(f"/jobs/{a.job_id}", status_code=302)


# Export endpoints
@router.get("/admin/export/users.csv")
async def export_users_csv(
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    buf = io.StringIO(newline="")
    writer = csv.writer(buf)
    writer.writerow(["id", "name", "email", "role", "is_active", "created_at"])

    for u in db.query(User).order_by(User.created_at.asc()).all():
        writer.writerow([
            u.id,
            u.name,
            u.email,
            u.role,
            1 if u.is_active else 0,
            (u.created_at or datetime.utcnow()).isoformat()
        ])

    return Response(
        content=buf.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=users.csv"}
    )


@router.get("/admin/export/jobs.csv")
async def export_jobs_csv(
        db: Session = Depends(get_db),
        user=Depends(login_required("admin"))
):
    buf = io.StringIO(newline="")
    writer = csv.writer(buf)
    writer.writerow([
        "id", "title", "reward", "city", "level", "is_remote",
        "tags", "status", "employer_email", "created_at"
    ])

    for j in db.query(Job).order_by(Job.created_at.asc()).all():
        employer_email = j.employer.email if j.employer else ""
        writer.writerow([
            j.id,
            j.title,
            j.reward,
            j.city or "",
            j.level or "",
            1 if j.is_remote else 0,
            j.tags or "",
            j.status,
            employer_email,
            (j.created_at or datetime.utcnow()).isoformat()
        ])

    return Response(
        content=buf.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=jobs.csv"}
    )

@router.get("/admin/users", response_class=HTMLResponse)
async def admin_users(request: Request, db: Session = Depends(get_db), user=Depends(login_required("admin"))):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return render("admin_users.html", request, users=users)

@router.post("/admin/users/{uid}/block")
async def admin_user_block(uid: int, db: Session = Depends(get_db), user=Depends(login_required("admin"))):
    u = db.get(User, uid)
    if not u: raise HTTPException(status_code=404)
    u.is_active = False
    db.commit()
    record_event(db, 'user_blocked', actor_id=user.id, target_id=u.id)
    return RedirectResponse("/admin/users", status_code=302)

@router.post("/admin/users/{uid}/unblock")
async def admin_user_unblock(uid: int, db: Session = Depends(get_db), user=Depends(login_required("admin"))):
    u = db.get(User, uid)
    if not u: raise HTTPException(status_code=404)
    u.is_active = True
    db.commit()
    record_event(db, 'user_unblocked', actor_id=user.id, target_id=u.id)
    return RedirectResponse("/admin/users", status_code=302)
