"""
Authentication routes
"""
from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from passlib.hash import pbkdf2_sha256 as hasher

from app.database import get_db, SessionLocal
from app.models.user import User
from app.templates import get_jinja_env
from app.dependencies import current_user

router = APIRouter()
env = get_jinja_env()


def render(name: str, request: Request, **context) -> HTMLResponse:
    """Render template with context"""
    with SessionLocal() as db:
        user = current_user(request, db)
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow(),
        **context
    })
    return HTMLResponse(html)


@router.get("/register", response_class=HTMLResponse)
async def register_form(request: Request, role: Optional[str] = None):
    return render("auth_register.html", request, pref_role=role or "employer")


@router.post("/register")
async def register(
        request: Request,
        name: str = Form(...),
        email: str = Form(...),
        password: str = Form(...),
        role: str = Form(...),
        accept_terms: Optional[str] = Form(None),
        db: Session = Depends(get_db)
):
    role = role.strip().lower()
    if role not in {"employer", "recruiter", "admin"}:
        return render("auth_register.html", request, error="Неверная роль", pref_role=role)

    if db.execute(select(User).where(User.email == email.strip().lower())).scalar_one_or_none():
        return render("auth_register.html", request, error="Email уже зарегистрирован", pref_role=role)

    if accept_terms != "1":
        return render("auth_register.html", request, error="Нужно принять условия использования", pref_role=role)

    user = User(
        name=name.strip(),
        email=email.strip().lower(),
        password_hash=hasher.hash(password),
        role=role,
        accepted_terms_at=datetime.utcnow(),
        is_active=True
    )
    db.add(user)
    db.commit()

    request.session["user_id"] = user.id
    request.session["role"] = user.role
    return RedirectResponse("/dashboard", status_code=302)


@router.get("/login", response_class=HTMLResponse)
async def login_form(request: Request):
    return render("auth_login.html", request)


@router.post("/login")
async def login(
        request: Request,
        email: str = Form(...),
        password: str = Form(...),
        db: Session = Depends(get_db)
):
    user = db.execute(select(User).where(User.email == email.strip().lower())).scalar_one_or_none()
    if not user or not user.verify_password(password) or not user.is_active:
        return render("auth_login.html", request, error="Неверные данные или пользователь заблокирован")

    request.session["user_id"] = user.id
    request.session["role"] = user.role
    return RedirectResponse("/dashboard", status_code=302)


@router.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=302)