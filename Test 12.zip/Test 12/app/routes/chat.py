"""
Chat and WebSocket routes
"""
import os
import json
import shutil
import uuid
from datetime import datetime
from typing import Dict, List, Tuple
from fastapi import APIRouter, Request, WebSocket, WebSocketDisconnect, UploadFile, File, Depends, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy import and_
from sqlalchemy.orm import Session

from app.database import get_db, SessionLocal
from app.models import Job, JobRecruiter, Message, Attachment, User
from app.templates import get_jinja_env
from app.dependencies import current_user, login_required
from app.utils import make_ws_token, verify_ws_token, escape_html, record_event, send_email_safe, send_telegram_safe
from app.config import UPLOAD_DIR, MAX_RECRUITERS_PER_JOB

router = APIRouter()
env = get_jinja_env()


def render(name: str, request: Request, **context) -> HTMLResponse:
    """Render template with context"""
    with SessionLocal() as db:
        user = current_user(request, db)
    html = env.get_template(name).render({
        "request": request,
        "user": user,
        "now": datetime.utcnow(),
        "max_recr": MAX_RECRUITERS_PER_JOB,
        **context
    })
    return HTMLResponse(html)


# WebSocket room manager
class ChatRoomManager:
    def __init__(self):
        self.connections: Dict[Tuple[int, int], List[WebSocket]] = {}

    async def connect(self, job_id: int, recruiter_id: int, websocket: WebSocket):
        await websocket.accept()
        key = (job_id, recruiter_id)
        if key not in self.connections:
            self.connections[key] = []
        self.connections[key].append(websocket)

    def disconnect(self, job_id: int, recruiter_id: int, websocket: WebSocket):
        key = (job_id, recruiter_id)
        if key in self.connections and websocket in self.connections[key]:
            self.connections[key].remove(websocket)
            if not self.connections[key]:
                del self.connections[key]

    async def broadcast_html(self, job_id: int, recruiter_id: int, html: str):
        key = (job_id, recruiter_id)
        if key in self.connections:
            for websocket in self.connections[key]:
                try:
                    await websocket.send_text(html)
                except:
                    pass


room_manager = ChatRoomManager()


@router.get("/chat/{job_id}/{recruiter_id}", response_class=HTMLResponse)
async def chat_page(
        request: Request,
        job_id: int,
        recruiter_id: int,
        db: Session = Depends(get_db)
):
    user = current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=302)

    job = db.get(Job, job_id)
    recruiter = db.get(User, recruiter_id)

    if not job or not recruiter or recruiter.role != "recruiter":
        raise HTTPException(status_code=404, detail="Not found")

    # Check if recruiter is assigned to this job
    is_assigned = db.query(JobRecruiter).filter(
        and_(JobRecruiter.job_id == job.id, JobRecruiter.recruiter_id == recruiter.id, JobRecruiter.status == "active")
    ).first()

    if not is_assigned:
        raise HTTPException(status_code=403, detail="No access to chat")

    if user.id not in {job.employer_id, recruiter.id}:
        raise HTTPException(status_code=403, detail="Not a participant")

    employer = db.get(User, job.employer_id)
    ws_token = make_ws_token(user.id, job.id, recruiter.id)

    return render("chat.html", request,
                  job=job,
                  recruiter=recruiter,
                  employer=employer,
                  ws_token=ws_token)


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, token: str = None):
    if not token:
        await websocket.close(code=4401)
        return

    try:
        uid, job_id, recruiter_id = verify_ws_token(token)
    except HTTPException:
        await websocket.close(code=4401)
        return

    await room_manager.connect(job_id, recruiter_id, websocket)

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                data = json.loads(raw)
            except Exception:
                continue

            if data.get('type') != 'message':
                continue

            content = (data.get('content') or '').strip()
            if not content:
                continue

            # Process message with database
            with SessionLocal() as db:
                job = db.get(Job, job_id)
                recruiter = db.get(User, recruiter_id)
                sender = db.get(User, uid)

                if not job or not recruiter or not sender:
                    continue

                # Verify access
                ok = False
                if uid in {job.employer_id, recruiter.id}:
                    is_assigned = db.query(JobRecruiter).filter(
                        and_(JobRecruiter.job_id == job.id, JobRecruiter.recruiter_id == recruiter.id,
                             JobRecruiter.status == "active")
                    ).first()
                    ok = bool(is_assigned)

                if not ok:
                    continue

                # Save message
                recipient_id = recruiter.id if uid == job.employer_id else job.employer_id
                msg = Message(
                    job_id=job.id,
                    recruiter_id=recruiter.id,
                    sender_id=uid,
                    recipient_id=recipient_id,
                    content=content
                )
                db.add(msg)
                db.commit()

                # Record event and send notifications
                record_event(db, 'message', actor_id=uid, job_id=job.id, recruiter_id=recruiter.id)

                try:
                    recipient = db.get(User, recipient_id)
                    send_email_safe(recipient.email, f"Новое сообщение: {job.title}", f"{sender.name}: {content}")
                except Exception:
                    pass

                send_telegram_safe(f"Сообщение по '{job.title}' от {sender.name}: {content}")

            # Broadcast message to all connections in this room
            html = f"""
            <div class="mb-2">
              <div class="inline-block px-3 py-2 rounded-xl bg-white border">
                <div class="text-xs opacity-70 mb-1">Сообщение • {datetime.utcnow().strftime('%H:%M %d.%m')} UTC</div>
                <div class="whitespace-pre-line">{escape_html(content)}</div>
              </div>
            </div>
            """
            await room_manager.broadcast_html(job_id, recruiter_id, html)

    except WebSocketDisconnect:
        room_manager.disconnect(job_id, recruiter_id, websocket)


@router.get("/api/chat/{job_id}/{recruiter_id}/list")
async def api_chat_list(
        request: Request,
        job_id: int,
        recruiter_id: int,
        db: Session = Depends(get_db)
):
    user = current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="auth")

    job = db.get(Job, job_id)
    recruiter = db.get(User, recruiter_id)

    if not job or not recruiter:
        raise HTTPException(status_code=404, detail="notfound")

    # Check assignment and access
    is_assigned = db.query(JobRecruiter).filter(
        and_(JobRecruiter.job_id == job.id, JobRecruiter.recruiter_id == recruiter.id, JobRecruiter.status == "active")
    ).first()

    if not is_assigned:
        raise HTTPException(status_code=403, detail="noaccess")

    if user.id not in {job.employer_id, recruiter.id}:
        raise HTTPException(status_code=403, detail="notparticipant")

    # Get messages
    msgs = db.query(Message).filter(
        and_(Message.job_id == job.id, Message.recruiter_id == recruiter.id)
    ).order_by(Message.timestamp.asc()).all()

    parts = []
    for m in msgs:
        mine = (m.sender_id == user.id)
        cls = "text-right" if mine else ""
        bubble = "bg-indigo-600 text-white" if mine else "bg-white border"
        label = "Вы" if mine else "Собеседник"
        content = escape_html(m.content)

        if m.attachment_id:
            parts.append(f"""
            <div class="mb-2 {cls}">
              <div class="inline-block px-3 py-2 rounded-xl {bubble}">
                <div class="text-xs opacity-70 mb-1">{label} • {m.timestamp.strftime('%H:%M %d.%m')}</div>
                <div class="whitespace-pre-line"><a class='underline' href='/uploads/{m.attachment_id}'>Файл</a></div>
              </div>
            </div>
            """)
        else:
            parts.append(f"""
            <div class="mb-2 {cls}">
              <div class="inline-block px-3 py-2 rounded-xl {bubble}">
                <div class="text-xs opacity-70 mb-1">{label} • {m.timestamp.strftime('%H:%M %d.%m')}</div>
                <div class="whitespace-pre-line">{content}</div>
              </div>
            </div>
            """)

    return HTMLResponse("\n".join(parts))


@router.post("/api/chat/{job_id}/{recruiter_id}/upload")
async def upload_attachment(
        job_id: int,
        recruiter_id: int,
        request: Request,
        f: UploadFile = File(...),
        db: Session = Depends(get_db)
):
    user = current_user(request, db)
    if not user:
        raise HTTPException(status_code=401)

    job = db.get(Job, job_id)
    recruiter = db.get(User, recruiter_id)

    if not job or not recruiter:
        raise HTTPException(status_code=404)

    # Check access
    is_assigned = db.query(JobRecruiter).filter(
        and_(JobRecruiter.job_id == job.id, JobRecruiter.recruiter_id == recruiter.id, JobRecruiter.status == "active")
    ).first()

    if not is_assigned or user.id not in {job.employer_id, recruiter.id}:
        raise HTTPException(status_code=403)

    # Save file
    ext = os.path.splitext(f.filename)[1]
    fname = f"{uuid.uuid4().hex}{ext}"
    dest = os.path.join(UPLOAD_DIR, fname)

    with open(dest, 'wb') as out:
        shutil.copyfileobj(f.file, out)

    # Save attachment record
    att = Attachment(filename=f.filename, path=fname, uploader_id=user.id)
    db.add(att)
    db.commit()

    # Save message with attachment
    msg = Message(
        job_id=job.id,
        recruiter_id=recruiter.id,
        sender_id=user.id,
        recipient_id=(recruiter.id if user.id == job.employer_id else job.employer_id),
        content=f"[Файл: {f.filename}]",
        attachment_id=att.id
    )
    db.add(msg)
    db.commit()

    record_event(db, 'message', actor_id=user.id, job_id=job.id, recruiter_id=recruiter.id)

    placeholder = f"Файл: {f.filename} — /uploads/{att.path}"
    return JSONResponse({"ok": True, "placeholder": placeholder, "id": att.id})


@router.get("/uploads/{att_id}")
async def get_upload(att_id: int, db: Session = Depends(get_db)):
    att = db.get(Attachment, att_id)
    if not att:
        raise HTTPException(status_code=404)
    return RedirectResponse(url=f"/uploads/{att.path}")