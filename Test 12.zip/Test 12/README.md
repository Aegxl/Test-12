# HR Team

A professional job marketplace platform where employers post job requests with rewards, and recruiters take them on, communicate via chat, and close positions. Everything is moderated with a transparent event history.

## Features

- **Job Management**: Employers create job requests, admins moderate them
- **Recruiter System**: Up to 3 recruiters per job with pipeline status tracking
- **Real-time Chat**: WebSocket-based chat with file attachments
- **Admin Panel**: User management, job moderation, invoice system
- **CMS System**: Editable pages for rules, terms, privacy policy
- **FAQ System**: Manageable frequently asked questions
- **Event Tracking**: Complete audit trail of all actions
- **Email & Telegram Notifications**: Automated notifications

## Project Structure

```
otvet-jobs-marketplace/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI app initialization
│   ├── config.py            # Configuration settings
│   ├── database.py          # Database setup
│   ├── dependencies.py      # FastAPI dependencies
│   ├── models/              # SQLAlchemy models
│   │   ├── __init__.py
│   │   ├── user.py         # User model
│   │   ├── job.py          # Job and JobRecruiter models
│   │   ├── message.py      # Message and Attachment models
│   │   ├── invoice.py      # Invoice model
│   │   ├── event.py        # Event model for audit trail
│   │   └── cms.py          # Page and FaqItem models
│   ├── templates/           # Jinja2 templates
│   │   ├── __init__.py
│   │   ├── base.py         # Base layout and landing page
│   │   ├── auth.py         # Authentication templates
│   │   ├── dashboard.py    # Dashboard templates
│   │   ├── job.py          # Job-related templates
│   │   ├── chat.py         # Chat interface
│   │   ├── admin.py        # Admin panel templates
│   │   └── cms.py          # CMS templates
│   ├── routes/              # Route handlers
│   │   ├── __init__.py
│   │   ├── auth.py         # Authentication routes
│   │   ├── dashboard.py    # Dashboard routes
│   │   ├── jobs.py         # Job management routes
│   │   ├── chat.py         # Chat and WebSocket routes
│   │   ├── admin.py        # Admin panel routes
│   │   └── cms.py          # CMS routes
│   └── utils/               # Utility functions
│       ├── __init__.py
│       ├── auth.py         # Authentication utilities
│       ├── email.py        # Email and Telegram notifications
│       └── helpers.py      # Helper functions
├── uploads/                 # File upload directory
├── .env.example            # Environment variables template
├── .gitignore
├── requirements.txt
├── main.py                 # Entry point
├── Dockerfile              # Docker container configuration
├── docker-compose.yml      # Docker Compose for development
├── MIGRATION.md           # Migration guide from single file
└── README.md
```

## Quick Start

### Using Docker Compose (Recommended)
```bash
git clone <repository-url>
cd otvet-jobs-marketplace
docker-compose up -d
```

Visit http://localhost:8000 and login with:
- **Email**: admin@otvet.kz
- **Password**: admin

### Manual Installation

### 1. Clone the repository
```bash
git clone <repository-url>
cd otvet-jobs-marketplace
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Environment Variables
Create a `.env` file or set the following environment variables:

```bash
# Required
SECRET_KEY=your-secret-key-here

# Database (default: SQLite)
DB_URL=sqlite:///market.db

# Upload directory (default: uploads/)
UPLOAD_DIR=uploads

# Email settings (optional)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=user@example.com
SMTP_PASS=password
EMAIL_FROM=noreply@otvet.kz

# Telegram notifications (optional)
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id

# Business settings
MAX_RECRUITERS_PER_JOB=3
```

### 4. Run the application

#### Development
```bash
python main.py
# or
uvicorn app.main:app --reload --port 8000
```

#### Production
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Default Credentials

After first startup, a default admin user is created:
- **Email**: admin@otvet.kz
- **Password**: admin

**⚠️ Change these credentials immediately in production!**

## User Roles

### Employer
- Create job requests
- View job details and assigned recruiters
- Chat with recruiters
- Track recruitment pipeline status

### Recruiter
- Browse and filter available jobs
- Take on jobs (up to 3 recruiters per job)
- Chat with employers
- Update pipeline status (invited → interview → offer → closed)

### Admin
- Moderate job requests (approve/reject)
- Manage users (block/unblock)
- Create and send invoices
- Manage CMS pages and FAQ
- View complete audit trail

## API Endpoints

### Public
- `GET /` - Landing page
- `GET /login` - Login form
- `POST /login` - Login action
- `GET /register` - Registration form
- `POST /register` - Registration action
- `GET /faq` - Public FAQ page
- `GET /page/{slug}` - View CMS page

### Authenticated
- `GET /dashboard` - Role-based dashboard
- `GET /logout` - Logout

### Jobs (Employers)
- `GET /jobs/new` - New job form
- `POST /jobs/new` - Create job
- `GET /jobs/{id}` - Job details
- `POST /jobs/{id}/toggle` - Open/close job

### Jobs (Recruiters)
- `POST /jobs/{id}/take` - Take on a job
- `POST /assign/{id}/stage` - Update pipeline status

### Chat
- `GET /chat/{job_id}/{recruiter_id}` - Chat interface
- `WebSocket /ws` - Real-time messaging
- `GET /api/chat/{job_id}/{recruiter_id}/list` - Message history
- `POST /api/chat/{job_id}/{recruiter_id}/upload` - File upload

### Admin
- `GET /admin` - Admin dashboard
- Various admin management endpoints...

## Database Schema

The application uses SQLAlchemy with the following main models:

- **User**: User accounts with roles (employer/recruiter/admin)
- **Job**: Job postings with status tracking
- **JobRecruiter**: Assignment relationship between jobs and recruiters
- **Message**: Chat messages between employers and recruiters
- **Attachment**: File attachments in chat
- **Invoice**: Billing system for employers
- **Event**: Audit trail of all system events
- **Page**: CMS pages (rules, terms, etc.)
- **FaqItem**: FAQ management

## Security Considerations

This is a development version. For production deployment:

1. Use strong `SECRET_KEY`
2. Use PostgreSQL/MySQL instead of SQLite
3. Enable HTTPS
4. Add CSRF protection
5. Implement rate limiting
6. Add file type/size validation
7. Use object storage for uploads
8. Add proper logging and monitoring
9. Implement backup strategy

## Development

### Project Architecture

This project follows a modular architecture:

- **Models**: SQLAlchemy ORM models for database entities
- **Routes**: FastAPI route handlers organized by feature
- **Templates**: Jinja2 templates with server-side rendering
- **Utils**: Shared utility functions and helpers
- **Dependencies**: FastAPI dependency injection for auth/db

### Adding New Features

1. **New Model**: Add to `app/models/` and update `__init__.py`
2. **New Route**: Create in appropriate `app/routes/` file
3. **New Template**: Add to corresponding `app/templates/` file
4. **New Utility**: Add to `app/utils/` with appropriate module

### Database Migrations

Currently using SQLAlchemy's `create_all()`. For production, consider using Alembic:

```bash
pip install alembic
alembic init alembic
# Configure alembic.ini and env.py
alembic revision --autogenerate -m "Initial migration"
alembic upgrade head
```

## Docker Deployment

Example Dockerfile:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
ENV DB_URL=sqlite:///market.db
ENV SECRET_KEY=change-me-in-production
EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## License

This project is provided as-is for educational and development purposes.

## Support

For questions or issues, please refer to the FAQ section or contact the development team.